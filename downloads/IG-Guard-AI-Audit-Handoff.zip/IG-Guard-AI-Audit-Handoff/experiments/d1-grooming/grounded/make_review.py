"""Build a source-linked workbook for paired case review and model errors."""
import argparse
from collections import defaultdict
import json
import math
from pathlib import Path
import unicodedata

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation


LANG = {"en": "English", "zh-Hant-yue": "Cantonese", "mixed": "Mixed Cantonese–English"}
MODE = {
    "igguard_keyword": "IG Guard keyword gate only",
    "original": "Original d1", "previous_edit": "Previous weight edit",
    "unedited_selected_question": "Unedited d1, selected question",
    "threshold_only": "Threshold-only control", "new_edit": "New weight edit",
}
INK = "163932"


def jsonl(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def constrain_sheet(sheet, widths, freeze="A2", table=True):
    sheet.freeze_panes = freeze
    if table:
        sheet.auto_filter.ref = sheet.dimensions
    for i, width in enumerate(widths, 1):
        sheet.column_dimensions[get_column_letter(i)].width = width
    for cell in sheet[1]:
        cell.fill = PatternFill("solid", fgColor=INK)
        cell.font = Font(color="FFFFFF", bold=True)
        cell.alignment = Alignment(wrap_text=True, vertical="center")
    sheet.row_dimensions[1].height = 28
    for row in sheet.iter_rows(min_row=2):
        lines = 1
        for cell in row:
            cell.alignment = Alignment(wrap_text=True, vertical="top")
            if isinstance(cell.value, str):
                cell.data_type = "s"
                estimate = 0
                for line in cell.value.splitlines():
                    display_width = sum(2 if unicodedata.east_asian_width(ch) in {"W", "F"} else 1
                                        for ch in line)
                    estimate += max(1, math.ceil(display_width / (widths[cell.column - 1] * .85)))
                lines = max(lines, estimate)
        sheet.row_dimensions[row[0].row].height = min(225, max(27, 16 * lines + 8))


def link(cell, url):
    cell.hyperlink = url
    cell.font = Font(color="14665B", underline="single")


def transcript(row):
    return "\n".join(f"{m['speaker']}: {m['text']}" for m in row["messages"])


def disposition(score, cutoff, label):
    decision = "Risk" if score >= cutoff else "Benign"
    if label == "review":
        return "In review band" if .35 <= score <= .65 else "Outside review band"
    if decision.lower() == label:
        return f"Correct {decision.lower()}"
    return "False positive" if decision == "Risk" else "False negative"


def review(data, results, output):
    rows = jsonl(data / "blind.jsonl")
    sources = {r["id"]: r for r in json.loads((data / "blind-sources.json").read_text())}
    benchmark = json.loads((results / "results.json").read_text())
    preds = {r["id"]: r for r in jsonl(results / "predictions.jsonl")}
    assert len(rows) == len(preds) == 90
    for row in rows:
        assert all(row[k] == preds[row["id"]][k] for k in ("label", "family", "incident", "language"))
    wb = Workbook()
    guide = wb.active
    guide.title = "Read me"
    guide.append(["IG Guard case-grounded d1 review", "How to use this workbook"])
    for row in [
        ("Paired review", "Risk and benign dialogues appear side by side in each language. The published case or safety example supplies the context. The dialogue and benign alternatives are de-identified adaptations."),
        ("Source classes", "Reported case identifies a published incident or case series. Education identifies examples in official guidance. Style-only references help with local phrasing and supply no labels."),
        ("Coverage", "72 binary cases and 18 insufficient-context cases. Conversations from one incident and their language versions share a split. Rows are related, so the 90 examples are not 90 independent incidents."),
        ("Expected alert", "A research triage label based on evidence visible in the exchange. A pressure cue or disclosure can merit review without establishing who committed abuse. Labels are for review."),
        ("Label review priorities", "The source and label check found that b03 and b06 contain implicit pressure cues. In b05, photo retention is visible, but the motive is unclear. In the benign b01 and b04, deletion and privacy are reported or promised. Use reviewer notes for disagreements. Scores use the frozen labels."),
        ("Keyword baseline", "The results include IG Guard’s captured keyword expression alone. It does not reproduce the full app’s collection, filtering or alert logic."),
        ("Scoring", "Binary decisions use 0.50 except the cutoff-only control, which was selected on the development set. Scores are d1 answers to a question. The inclusive 0.35–0.65 review band is reported separately for insufficient-context cases."),
        ("Quality target", "At least 80% risk recall and at most 20% benign false alarms overall. At least 70% recall and at most 30% false alarms in each language group."),
    ]:
        guide.append(row)
    constrain_sheet(guide, [33, 105], table=False)

    overview = wb.create_sheet("Results")
    overview.append(["Model condition", "Language", "Risk caught", "Risk cases", "Benign flagged",
                     "Benign cases", "Recall", "False positive rate", "Both paired labels correct",
                     "Risk version scored higher", "Pairs", "In review band", "Review cases", "Threshold"])
    for name, values in benchmark["metrics"].items():
        for lang, score in values["binary"].items():
            pairs = values["pairs"][lang]
            overview.append([MODE[name], LANG.get(lang, "All"), score["tp"], score["tp"]+score["fn"],
                             score["fp"], score["fp"]+score["tn"], score["recall"], score["false_positive_rate"],
                             pairs["both_correct"], pairs["risk_scored_higher"], pairs["pairs"],
                             score["gold_review_in_band"], score["gold_review_total"], values["cutoff"]])
    constrain_sheet(overview, [37, 25, 12, 12, 14, 14, 12, 16, 19, 19, 10, 14, 14, 13])
    for r in overview.iter_rows(min_row=2):
        for i in (6, 7):
            r[i].number_format = "0.0%"

    paired = wb.create_sheet("Paired conversations")
    paired.append(["Family", "Language", "Risk conversation", "Matched benign conversation", "Why risk",
                   "Why benign", "Source", "Section or locator", "Reviewer notes"])
    by_pair = defaultdict(dict)
    for row in rows:
        if row["label"] != "review":
            by_pair[row["family"], row["language"]][row["label"]] = row
    for (family, lang), p in sorted(by_pair.items(), key=lambda item: (item[0][0], list(LANG).index(item[0][1]))):
        risk, normal = p["risk"], p["benign"]
        src = sources[risk["source_id"]]
        paired.append([family, LANG[lang], transcript(risk), transcript(normal), risk["label_reason"],
                       normal["label_reason"], src["title"], src["locator"], None])
        link(paired.cell(paired.max_row, 7), src["url"])
    constrain_sheet(paired, [15, 24, 67, 67, 40, 40, 34, 31, 44], freeze="C2")

    cases = wb.create_sheet("Case scores")
    cases.append(["Case ID", "Incident group", "Language", "Expected label", "Full conversation", "Expected cue",
                  "Source", "Original score", "Original result", "Previous-edit score", "Previous-edit result",
                  "New-edit score", "New-edit result", "Reviewer label", "Reviewer notes"])
    for row in rows:
        p = preds[row["id"]]["scores"]
        src = sources[row["source_id"]]
        label = row["label"]
        metrics = []
        for model in ("original", "previous_edit", "new_edit"):
            metrics.extend([p[model], disposition(p[model], benchmark["metrics"][model]["cutoff"], label)])
        expected = "Insufficient context" if label == "review" else label.title()
        cases.append([row["id"], row["incident"], LANG[row["language"]], expected,
                      transcript(row), row["label_reason"], src["title"], *metrics, None, None])
        link(cases.cell(cases.max_row, 7), src["url"])
    constrain_sheet(cases, [26, 28, 24, 22, 77, 42, 35, 14, 21, 14, 21, 14, 21, 22, 42], freeze="E2")
    for cells in cases.iter_rows(min_row=2):
        for i in (7, 9, 11):
            cells[i].number_format = "0.000000"
        for i in (8, 10, 12):
            if cells[i].value in {"False positive", "False negative"}:
                cells[i].fill = PatternFill("solid", fgColor="FCE5DE")
    dv = DataValidation(type="list", formula1='"Risk,Benign,Insufficient context"', allow_blank=True)
    cases.add_data_validation(dv)
    dv.add(f"N2:N{cases.max_row}")

    refs = wb.create_sheet("Sources")
    refs.append(["Source ID", "Title", "Source class", "Section or locator", "What the source supports", "URL"])
    reviewed = json.loads(Path(__file__).with_name("sources-reviewed.json").read_text())
    for item in list(sources.values()) + reviewed:
        refs.append([item["id"], item["title"], item["type"], item.get("locator", "Background or corroboration"),
                     item["supports"], item["url"]])
        link(refs.cell(refs.max_row, 6), item["url"])
    constrain_sheet(refs, [20, 40, 21, 40, 68, 56])
    wb.save(output)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--results", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    review(args.data, args.results, args.output)
