# IG Guard d1 follow-up with published safeguarding cases

Dated 18 November 2026, Hong Kong. The dialogues in the spreadsheet are de-identified,
case-based adaptations. Where reporting includes a neutral fragment of a real message,
the case source distinguishes the published language from the reconstructed dialogue.
The benign version keeps the ordinary opening and shared topic, then changes the
visible behavior that determines whether the exchange warrants review.

The source material includes BBC's coverage of police-released messages, HK01's
reporting on the Police seminar and related cases, Hampshire's practitioner case
summaries, and CyberDefender's official examples. LIHKG informed local register only.
Cheshire and Hong Kong police statements supply corroboration and context respectively.
The workbook lists the source and locator for each pair, along with the cue used
to assign the expected label. [Source register](sources-reviewed.json)

The English versions of pair b01 both retain the BBC-reported phrase “That's fine w me.”
In the risk adaptation the person reveals that they kept a private copy despite the
refusal. In the benign version they respect the request and confirm deletion. The
Cantonese pair b04 draws on HK01's reported dating-app case. It distinguishes using
a private image to threaten someone who declines another meeting from accepting the
refusal and keeping the image private. The article supplies the incident summary;
the Cantonese dialogue is an adaptation. [Case citations](data/blind-sources.json)

The fitting and selection sets contain 78 and 48 cases respectively. The independently
prepared holdout contains 72 binary examples, balanced between 36 risk and 36 benign
conversations, plus 18 insufficient-context examples. Each of the 12 paired test families
has English, Cantonese and mixed Cantonese–English versions. All 36 risk/benign pairs
share their opening message. Ten families are based on reported cases and two on
official prevention examples, across eight incident or guidance groups. All windows
from the same underlying group stay in the same split. The benchmark measures recognition of
specified cues on public-source adaptations. It cannot estimate a real-world false alarm
rate for Instagram or confirm that someone is an offender.

We kept LiquidAI/d1-omni-600M at the original pinned F32 revision. The fitter compared the
original question and a context-focused question, applying 24 gradient-free edits to the
final 1,024-weight layer for each question. It used the 48 selection cases to freeze the
choice. Fitting never opened the holdout. The original d1 weights, previous edit, and
threshold-only control provide comparisons. The keyword row reuses the prior captured
expression and is narrower than IG Guard's full alert logic. [Reproduction instructions](README.md)

The gate uses at least 80% recall and at most 20% benign false alarms overall, and at
least 70% recall and at most 30% false alarms in each language group. The 18 partial
exchanges are scored separately against the original review band. They do not enter
the binary recall or false-alarm counts.

Two examples deserve particular attention during label review. The risk version of b03
shows a contact responding more warmly after a young person reconsiders a photo request.
That can indicate conditional attention, but intent is uncertain in a short excerpt.
The risk version of b05 shows non-consensual retention of a photo, which can warrant a
privacy or safeguarding review while leaving the motive unclear. The benchmark retains
its frozen labels and provides fields for a reviewer to disagree.

A separate reviewer, without model scores, checked all 12 English pairs, the six
ambiguous English windows, and three Cantonese variants. The reviewer found credible
benign endings and supported the six insufficient-context labels. They flagged b03
and b06 as implicit cues that merit human judgment. They also noted that b01's deletion
is self-reported and b04's privacy is a promise. Several adapted details, including the
exact meeting refusal, who overrode a peer's refusal, and the school message route,
come from the reconstruction. The source locators and review notes retain that
distinction. The frozen scores and labels were kept for comparison.


## Blind results

| Condition | Risk caught | Benign flagged | Both labels right within pair | Risk scored higher within pair |
| --- | ---: | ---: | ---: | ---: |
| IG Guard keyword expression only | 1/36 | 1/36 | 0/36 | 0/36 |
| Original d1, original question | 32/36 | 29/36 | 4/36 | 21/36 |
| Previous weight edit, original question | 26/36 | 30/36 | 0/36 | 25/36 |
| Unedited d1, context question | 1/36 | 0/36 | 1/36 | 21/36 |
| Context question, cutoff selected on development | 20/36 | 15/36 | 6/36 | 21/36 |
| New final-scorer edit, context question | 17/36 | 13/36 | 6/36 | 16/36 |

**The new edit missed the quality gate.** Relative to original d1 it produced 16 fewer
false alarms and caught 15 fewer risk conversations. The threshold-only control caught
20 risk cases and flagged 15 benign cases, versus 17 and 13 for the weight edit.
The edit ranked the risk version above its benign counterpart in 16 of 36 pairs,
versus 21 for original d1. This gives little evidence that the edit learned the
case distinction. [Metrics](results/results.json) · [Each score](results/predictions.jsonl)

The new edit caught 2/12 English risk cases and flagged 0/12 benign cases. For
Cantonese the counts were 8/12 and 6/12. For mixed Cantonese–English they were
7/12 and 7/12. On insufficient-context cases, 13/18 scores fell within the review
band, compared with 6/18 for the original model. The review band describes score
behavior on these partial exchanges only.

The selected patch is a 4.3 KB safetensors file tied to the pinned model's hash.
It replaces 1,024 weights in the final scorer tensor and is loaded by the normal d1 scoring path.
The experiment stays with d1. Its results do not support enabling this edit for
automatic family alerts. [Frozen fitting record](results/freeze.json) · [Weight patch](results/d1-grooming-head.safetensors)

All four model passes scored the same 90 cases on CPU in 291 seconds in total.
The additional threshold and keyword controls reused scores or evaluated the
captured expression. This timing does not measure Android performance.
[Timing](results/evaluation-timing.json)
