"""Offline d1 experiment on de-identified adaptations of safeguarding sources."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import itertools
import json
import math
from pathlib import Path
import re
import resource
import sys
import time

import torch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import weight_edit as w
from fetch_model import sha256
from run import baseline, read_json, write_json

PREFIX = {"fit": "f", "selection": "v", "blind": "b"}


def load_json(path):
    return json.loads(path.read_text())


def read_split(root, split):
    rows = w.fixture(root / f"{split}.jsonl", PREFIX[split], allow_review=split == "blind")
    sources = load_json(root / f"{split}-sources.json")
    by_id = {s["id"]: s for s in sources}
    if len(by_id) != len(sources):
        raise ValueError(f"Duplicate source IDs in {split}")
    families = {}
    for row in rows:
        source = by_id.get(row["source_id"])
        if not source or source["type"] not in {"reported_case", "education"}:
            raise ValueError(f"No case evidence citation for {row['id']}")
        if not row["incident"].strip() or not row["label_reason"].strip():
            raise ValueError(f"No incident group or cue for {row['id']}")
        if not source["url"].startswith("https://") or not source["supports"].strip():
            raise ValueError(f"Incomplete citation for {row['id']}")
        group = (row["incident"], row["source_id"])
        if families.setdefault(row["family"], group) != group:
            raise ValueError(f"Mixed source evidence inside {row['family']}")
    return rows


def validate_disjoint(splits):
    incidents, ids, families, conversations = {}, set(), {}, {}
    for split, rows in splits.items():
        for row in rows:
            for key, seen in (("incident", incidents), ("family", families)):
                if seen.setdefault(row[key], split) != split:
                    raise ValueError(f"Same {key} crosses splits: {row[key]}")
            if row["id"] in ids:
                raise ValueError(f"Duplicate case ID: {row['id']}")
            ids.add(row["id"])
            chat = json.dumps(row["messages"], ensure_ascii=False, sort_keys=True)
            if conversations.setdefault(chat, split) != split:
                raise ValueError("Identical conversations cross splits")


def pair_summary(rows, scores, threshold):
    pairs = {}
    for row, score in zip(rows, scores, strict=True):
        if row["label"] != "review":
            key = (row["family"], row["language"])
            pairs.setdefault(key, {})[row["label"]] = float(score)
    result = {language: {"pairs": 0, "both_correct": 0, "risk_scored_higher": 0}
              for language in ("all", *w.LANGUAGES)}
    for (_, language), pair in pairs.items():
        risk, benign = pair["risk"], pair["benign"]
        for name in (language, "all"):
            result[name]["pairs"] += 1
            result[name]["both_correct"] += int(risk >= threshold > benign)
            result[name]["risk_scored_higher"] += int(risk > benign)
    return result


def development_summary(rows, scores, cutoff):
    return {"binary": w.groups(rows, scores, cutoff), "pairs": pair_summary(rows, scores, cutoff)}


def fit_options(model, train, validation, questions, protocol):
    original = model.head.scorer[3].weight.detach()[0].clone()
    targets = torch.tensor([2. if r["label"] == "risk" else -2. for r in train])
    cutoff = protocol["binary_threshold"]
    best = None
    evidence = {}
    for question_name, question in questions.items():
        print(f"Fitting {question_name} using only fit and selection cases", flush=True)
        _, train_features = w.infer(model, train, question, protocol["batch_size"], capture=True)
        scores, val_features = w.infer(model, validation, question, protocol["batch_size"], capture=True)
        pair_features, pair_targets = w.paired_differences(train_features, targets, train)
        cutoffs = sorted({cutoff, *[float(x) for x in scores]})
        cutoffs.append(math.nextafter(cutoffs[-1], math.inf))
        tuned_cut, tuned = max(
            ((c, development_summary(validation, scores, c)) for c in cutoffs),
            key=lambda item: (*w.rank(item[1]["binary"], protocol), -abs(item[0] - cutoff)),
        )
        evidence[question_name] = {
            "unedited": development_summary(validation, scores, cutoff),
            "threshold_only": {"cutoff": tuned_cut, **tuned},
        }
        candidates = []
        for contrast, ridge, scale in itertools.product(
            protocol["contrast_weights"], protocol["ridge_fractions"], protocol["edit_scales"]
        ):
            x = train_features
            y = targets
            if contrast:
                factor = math.sqrt(contrast)
                x = torch.cat((x, factor * pair_features))
                y = torch.cat((y, factor * pair_targets))
            weight = original + scale * w.fit_delta(x, y, original, ridge)
            edited = (val_features @ weight).sigmoid()
            summary = development_summary(validation, edited, cutoff)
            norm = float((weight - original).norm())
            result = {"question": question_name, "ridge_fraction": ridge,
                      "pair_contrast_weight": contrast, "scale": scale,
                      "edit_l2": norm, **summary}
            rank = (*w.rank(summary["binary"], protocol),
                    summary["pairs"]["all"]["both_correct"], -norm)
            candidates.append((rank, result))
            if best is None or rank > best[0]:
                best = (rank, result, weight, edited)
        evidence[question_name]["best_weight_edit"] = max(candidates, key=lambda x: x[0])[1]
    return best[1:], evidence


def frozen_inputs(root, filenames):
    return {name: sha256(root / name) for name in filenames}


def fit(args, protocol, questions):
    holdout_hashes = {"blind.jsonl": args.blind_sha256,
                      "blind-sources.json": args.blind_sources_sha256}
    if any(not re.fullmatch("[0-9a-f]{64}", value or "") for value in holdout_hashes.values()):
        raise ValueError("Fit requires the sealed holdout and source-table hashes")
    names = ("fit.jsonl", "fit-sources.json", "selection.jsonl", "selection-sources.json")
    hashes = frozen_inputs(args.data, names)
    train = read_split(args.data, "fit")
    selection = read_split(args.data, "selection")
    validate_disjoint({"fit": train, "selection": selection})
    model, base_hash = w.load_model(args.snapshot, protocol, args.output)
    (result, weight, reconstructed), evidence = fit_options(model, train, selection, questions, protocol)
    patch = args.output / w.PATCH_NAME
    w.write_patch(patch, weight[None], base_hash)
    w.apply_patch(model.head.scorer, patch, base_hash)
    live = w.infer(model, selection, questions[result["question"]], protocol["batch_size"])
    torch.testing.assert_close(live, reconstructed, atol=3e-5, rtol=0)
    cutoff = protocol["binary_threshold"]
    if not torch.equal(live >= cutoff, reconstructed >= cutoff):
        raise ValueError("Live model and captured activations disagree at the cutoff")
    if frozen_inputs(args.data, names) != hashes:
        raise ValueError("Fit or selection inputs changed")
    record = {
        "blind_sha256": args.blind_sha256, "blind_inputs": holdout_hashes,
        "frozen_utc": datetime.now(timezone.utc).isoformat(), "fit_inputs": hashes,
        "model_checkpoint_sha256": base_hash, "patch_sha256": sha256(patch),
        "prior_patch_sha256": sha256(prior_patch()),
        "protocol": protocol, "questions": questions,
        "fit_rows": len(train), "selection_rows": len(selection),
        "fit_incidents": len({r["incident"] for r in train}),
        "selection_incidents": len({r["incident"] for r in selection}),
        "chosen": result, "development": evidence,
    }
    write_json(args.output / "freeze.json", record)
    print("Frozen variant", result["question"], result["binary"]["all"], flush=True)


def prior_patch():
    return HERE.parent / "results" / "weight-edit" / w.PATCH_NAME


def evaluate(args, protocol, questions):
    if args.freeze is None:
        raise ValueError("Evaluate requires the frozen candidate directory")
    record = load_json(args.freeze / "freeze.json")
    new_patch = args.freeze / w.PATCH_NAME
    if (frozen_inputs(args.data, record["blind_inputs"]) != record["blind_inputs"]
            or frozen_inputs(args.data, record["fit_inputs"]) != record["fit_inputs"]
            or sha256(new_patch) != record["patch_sha256"]
            or sha256(prior_patch()) != record["prior_patch_sha256"]
            or protocol != record["protocol"] or questions != record["questions"]):
        raise ValueError("The checkpoint, protocol or fixture differs from the frozen experiment")
    all_splits = {split: read_split(args.data, split) for split in PREFIX}
    validate_disjoint(all_splits)
    rows = all_splits["blind"]
    expected = {"risk": 36, "benign": 36, "review": 18}
    if Counter(r["label"] for r in rows) != expected:
        raise ValueError("Blind fixture must contain the planned 90 cases")
    model, base_hash = w.load_model(args.snapshot, protocol, args.output)
    if base_hash != record["model_checkpoint_sha256"]:
        raise ValueError("Evaluation checkpoint differs from fitting")
    layers = (model.head.scorer[1], model.head.scorer[3])
    originals = [{k: v.detach().clone() for k, v in layer.state_dict().items()} for layer in layers]
    question_name = record["chosen"]["question"]
    q, selected = questions["original"], questions[question_name]
    batch_size = protocol["batch_size"]

    def score(name, question):
        print(f"Scoring {name}", flush=True)
        return w.infer(model, rows, question, batch_size)

    original = score("original", q)
    unedited_selected = original if question_name == "original" else score("unedited selected question", selected)
    w.apply_patch(model.head.scorer, prior_patch(), base_hash)
    previous = score("previous edit", q)
    for layer, state in zip(layers, originals):
        layer.load_state_dict(state)
    w.apply_patch(model.head.scorer, new_patch, base_hash)
    edited = score("new weights", selected)
    cutoff = protocol["binary_threshold"]
    tuned_cutoff = record["development"][question_name]["threshold_only"]["cutoff"]
    pattern = re.compile(read_json("baseline.json")["pattern"], re.IGNORECASE)
    keyword = [float(baseline(row, pattern)) for row in rows]
    conditions = {
        "igguard_keyword": (keyword, cutoff),
        "original": (original, cutoff),
        "previous_edit": (previous, cutoff),
        "unedited_selected_question": (unedited_selected, cutoff),
        "threshold_only": (unedited_selected, tuned_cutoff),
        "new_edit": (edited, cutoff),
    }
    metrics = {
        name: {"cutoff": cut, **development_summary(rows, scores, cut)}
        for name, (scores, cut) in conditions.items()
    }
    for values in metrics.values():
        values["gate"] = w.gate(values["binary"], protocol)
    with (args.output / "predictions.jsonl").open("w") as fp:
        for i, row in enumerate(rows):
            output = {key: row[key] for key in ("id", "label", "family", "incident", "language")}
            output["scores"] = {name: float(scores[i]) for name, (scores, _) in conditions.items()}
            fp.write(json.dumps(output, ensure_ascii=False, allow_nan=False) + "\n")
    write_json(args.output / "results.json", {
        "metrics": metrics, "selected_question": question_name,
        "blind_sha256": record["blind_sha256"], "patch_sha256": record["patch_sha256"],
        "counts": expected, "incident_groups": len({row["incident"] for row in rows}),
    })
    print("Blind gate", metrics["new_edit"]["gate"], flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("fit", "evaluate"))
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--snapshot", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--blind-sha256")
    parser.add_argument("--blind-sources-sha256")
    parser.add_argument("--freeze", type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    start = time.perf_counter()
    protocol = read_json("weight-protocol.json")
    questions = {"original": read_json("questions.json"),
                 "context": load_json(HERE / "context-question.json")}
    (fit if args.stage == "fit" else evaluate)(args, protocol, questions)
    write_json(args.output / "timing.json", {
        "elapsed_seconds": time.perf_counter() - start,
        "peak_rss_mib_linux": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024,
        "torch": torch.__version__,
    })


if __name__ == "__main__":
    main()
