import unittest

from grounded_eval import pair_summary, validate_disjoint


class GroundedTests(unittest.TestCase):
    def test_an_incident_shared_across_translations_cannot_cross_splits(self):
        with self.assertRaisesRegex(ValueError, "incident"):
            validate_disjoint({
                "fit": [{"incident": "reported-1", "family": "f01", "id": "f01-risk-en",
                         "messages": [{"speaker": "a", "text": "first"}]}],
                "blind": [{"incident": "reported-1", "family": "b01", "id": "b01-risk-zh-Hant-yue",
                           "messages": [{"speaker": "a", "text": "another"}]}],
            })

    def test_pairs_separate_alerts_from_keyword_matches(self):
        cases = [{"family": f, "language": "en", "label": l}
                 for f in ("b01", "b02", "b03") for l in ("risk", "benign")]
        metrics = pair_summary(cases, [0.8, 0.7, 0.6, 0.4, 0.35, 0.3], 0.5)["all"]
        self.assertEqual(metrics, {"pairs": 3, "both_correct": 1, "risk_scored_higher": 3})


if __name__ == "__main__":
    unittest.main()
