# IG Guard case-grounded d1 evaluation

This follow-up tests what the model does when two otherwise similar conversations turn on
an observable safeguarding cue. A risk label asks for a person to review the exchange.
Its presence does not identify an offender or establish that abuse occurred.

The test contains matched risk and benign versions in English, Hong Kong Cantonese and
mixed Cantonese–English. Sources supply the situations and documented cues. The reviewed
dialogues are de-identified adaptations. The test includes brief windows with too little
context for a binary label. The researchers compared those scores with the earlier inclusive
0.35–0.65 review band.

Sources are classified at the row level. BBC's case reporting describes police-released
messages and gives some fragments in text. HK01 and Hampshire's safeguarding case studies
offer incident narratives. CyberDefender provides official prevention examples. LIHKG informs
local phrasing only. Group all windows from the same underlying case and all translations
together. A large number of rows can represent a small number of independent incidents.

## Reproduce

Use the parent experiment's pinned dependency lock and the verified original F32
LiquidAI/d1-omni-600M snapshot. The prior edited scorer comes from the first experiment's
results. The holdout and its citation table are hashed before model selection.
Run these commands from the parent experiment directory. Use new output directories.
Generating the spreadsheet requires OpenPyXL.

```bash
python -m unittest discover -s grounded -v
python grounded/grounded_eval.py fit --data grounded/data --snapshot /path/to/base \
  --blind-sha256 <holdout-digest> --blind-sources-sha256 <source-table-digest> \
  --output /tmp/d1-grounded-fit
python grounded/grounded_eval.py evaluate --data grounded/data --snapshot /path/to/base \
  --freeze /tmp/d1-grounded-fit --output /tmp/d1-grounded-blind
python grounded/make_review.py --data grounded/data --results /tmp/d1-grounded-blind \
  --output /tmp/d1-grounded-review.xlsx
```

The fitter reads the fitting and selection inputs. It receives hashes for the blind inputs
and selects the question and weight edit without opening either blind file. Candidate rank
uses the predeclared quality gate, the weakest overall or language-group recall minus
false-positive rate, the overall margin, the overall false-positive rate, the number of
pairs classified correctly, and the edit size. Selection preserves the research cutoff of
0.5. A threshold-only baseline uses a cutoff picked from the selection split.

Evaluation runs the frozen choice through d1's ordinary System One inference, with
original checkpoint and prior edit controls. The review workbook keeps expected labels
and model errors beside each exchange. Fixtures are localized across languages, so this
benchmark measures behavior on these case-based adaptations. It does not provide a
population abuse rate or accuracy estimates on real private messages.

The patch changes the final decision scorer's F32 weight, leaving the base file and other
tensors untouched. To apply the patch programmatically, load the pinned model and call
`weight_edit.apply_patch(model.head.scorer, path, base_checkpoint_sha256)`. Apply the selected
question from `freeze.json` when scoring. The patch and upstream license are supplied together.
