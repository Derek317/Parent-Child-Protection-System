# Conversation risk scoring preview

The pinned d1 model scores four ordered concern levels using its native System One
`score` question. The research harness converts the expected level to a score out of
100 using `100 × (P₁ + 2P₂ + 3P₃) / 3`. These are uncalibrated assessments of the supplied
text. The scores do not estimate the probability of abuse or describe the child.

| Band | Score | Visible behavior in the rubric |
| --- | --- | --- |
| Low risk | 0 to below 25 | Ordinary exchange with respected boundaries |
| Potentially risky | 25 to below 50 | Ambiguous concern that needs context |
| Moderate risk | 50 to below 75 | Persistent pressure, conditional reward, or a breach of privacy |
| High risk | 75 to 100 | Coercion, threat of exposure, or credible disclosure of serious harm |

The threshold numbers are experimental. Each conversation contributes one equally
weighted score. Blank conversations and serialized conversations above 8 KiB go to
review. For other conversations,
a separate evidence-sufficiency answer below 0.5 or a largest level probability
below 0.4 sends the conversation to review. The app displays the average, highest
score, count in each band, and the scored and pending-review counts. Review items have
no numeric value. If all conversations need review, the average and highest score
are unavailable. The highest score helps preserve the visibility of a single
concerning exchange among many low scores.

## Try the Android preview

In the debug build, select the parent role and unlock it with the Android device
credential. In the overview, open **對話風險評分（試驗）**, select a
[context-study demo file](context-results/test/score-report.json) and reauthenticate upon returning
from Android's picker. The summary then opens. Use a spare device for the debug
build. Its package ID matches the release app and its signing certificate differs.

The preview reads a user-selected file containing opaque conversation numbers, scores,
and review reasons, plus an optional weight patch digest. The parser rejects
duplicate and unknown fields, including message text. The UI labels file provenance
as unverified.
The summary stays in memory for the current activity and family session.
The selected file remains at its chosen location. The debug APK runs the summary
UI. CPU inference runs in the separate local harness. Inference on Android hardware
remains unverified.

The [context study](context-results/REPORT.md) compares three versions of the
same model on 60 held-out conversations. Its [case review](context-results/test/case-review.csv)
matches each score or referral to the wording, reference judgment and source.
The [dataset protocol](context-data/README.md) explains how the examples were
constructed. The [original 90-case demo](results/score-report.json) is also available.

## Reproduce the scores locally

From `experiments/d1-grooming`, set up the verified snapshot and pinned Python
environment as described in the [research harness README](../README.md). Use a new
directory for each run.

```bash
python -m unittest discover -s ordinal -v
python ordinal/score.py --replay --snapshot /path/to/snapshot --output /tmp/d1-ordinal-replay
```

Use the following commands to reproduce the [weight-edit comparison](weight-edit/REPORT.md).

```bash
python ordinal/fit_scorer.py --snapshot /path/to/snapshot --output /tmp/d1-ordinal-fit
python ordinal/score.py --replay --snapshot /path/to/snapshot \
  --patch /tmp/d1-ordinal-fit/d1-ordinal-head.safetensors --output /tmp/d1-ordinal-edited
```

Use `--input /path/to/conversations.jsonl` in place of `--replay` to score a local file
that you are authorized to process. The example below shows one row per conversation
with messages in chronological order.

```json
{"id":"club-chat-1","messages":[{"speaker":"peer","text":"Can I share your poster?"},{"speaker":"student","text":"Please wait until tomorrow."},{"speaker":"peer","text":"Sure, I'll wait."}]}
```

The CLI accepts at most 500 conversations and 100 messages per conversation. It runs
offline after snapshot setup and emits a score-only report with local IDs, without
speaker names or messages. Transfer the score report you want to review using the
Android file picker. Model output for real use remains unvalidated. Consult the
[replay results](REPORT.md) before interpreting the demo.
