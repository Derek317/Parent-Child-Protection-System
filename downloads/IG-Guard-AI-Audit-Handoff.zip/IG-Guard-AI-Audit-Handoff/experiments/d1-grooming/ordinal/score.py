"""Score conversations locally with d1's native ordered decision API."""
import argparse
from collections import Counter
from hashlib import sha256
import json
import math
from pathlib import Path
import statistics
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
RUBRIC = json.loads((HERE / "rubric.json").read_text())
BANDS = [item["min"] for item in RUBRIC["bands"]]
MODEL = "LiquidAI/d1-omni-600M"
MAX_CONVERSATIONS = 500
MAX_INPUT_BYTES = 5 * 1024 * 1024
MAX_CONTEXT_BYTES = 8192


def band(score):
    if type(score) not in (int, float) or not math.isfinite(score) or not 0 <= score <= 100:
        raise ValueError("Risk score must be a finite number between 0 and 100")
    return sum(score >= threshold for threshold in BANDS[1:])


def probability(value):
    if type(value) not in (int, float) or not math.isfinite(value) or not 0 <= value <= 1:
        raise ValueError("Invalid d1 probability")
    return value


def assess(response):
    severity = response["answers"]["severity"]
    enough = response["answers"]["enough"]
    if severity["type"] != "score" or enough["type"] != "noul" or response["usage"]["output_tokens"] != 0:
        raise ValueError("Expected native System One scores")
    levels = severity["probabilities"]
    if set(levels) != {"0", "1", "2", "3"}:
        raise ValueError("Expected four severity levels")
    probabilities = [probability(levels[str(i)]) for i in range(4)]
    expectation = sum(i * value for i, value in enumerate(probabilities))
    if (abs(sum(probabilities) - 1) > 1e-5
            or not math.isclose(expectation, severity["score"], abs_tol=1e-5)):
        raise ValueError("Inconsistent d1 severity score")
    context = probability(enough["noul"])
    confidence = max(probabilities)
    raw_score = min(100.0, 100.0 * expectation / 3)
    reason = None
    if context < RUBRIC["context_min"]:
        reason = "insufficient_context"
    elif confidence < RUBRIC["level_confidence_min"]:
        reason = "uncertain_score"
    return {"score": raw_score if reason is None else None, "review_reason": reason,
            "raw_score": raw_score, "context": context, "distribution": probabilities}


def summarize(assessments):
    scores = [a["score"] for a in assessments if a["score"] is not None]
    return {"mean": statistics.fmean(scores) if scores else None,
            "highest": max(scores) if scores else None,
            "scored": len(scores), "review": len(assessments) - len(scores),
            "band_counts": dict(Counter(band(s) for s in scores))}


def read_cases(path):
    with path.open("rb") as file:
        data = file.read(MAX_INPUT_BYTES + 1)
    if len(data) > MAX_INPUT_BYTES:
        raise ValueError("Conversation file exceeds 5 MiB")
    rows = [json.loads(line) for line in data.decode("utf-8").splitlines() if line.strip()]
    if not 1 <= len(rows) <= MAX_CONVERSATIONS:
        raise ValueError(f"Provide 1 to {MAX_CONVERSATIONS} conversations")
    ids = set()
    for row in rows:
        identifier = row["id"]
        if not isinstance(identifier, str) or not identifier.strip() or identifier in ids:
            raise ValueError("Each conversation must have a unique, nonempty ID")
        ids.add(identifier)
        messages = row["messages"]
        if not isinstance(messages, list) or not 0 <= len(messages) <= 100:
            raise ValueError("Each conversation must contain at most 100 messages")
        for message in messages:
            if set(message) != {"speaker", "text"} or not all(
                isinstance(s, str) and s.strip() for s in message.values()
            ):
                raise ValueError("A message needs a nonempty speaker and text")
    return rows, sha256(data).hexdigest()


def context_fits(messages):
    # The pinned model allows 16k tokens. Keeping the input below 8 KiB
    # avoids silent context truncation on this prototype.
    return len(json.dumps({"chat": messages}, ensure_ascii=False).encode("utf-8")) <= MAX_CONTEXT_BYTES


def replay_metrics(rows):
    levels = ["low", "potential", "moderate", "high", "review"]
    confusion = {expected: {predicted: 0 for predicted in levels} for expected in levels}
    pairs, errors = {}, []
    for row in rows:
        score, expected = row["score"], row["expected_band"]
        estimated = 4 if score is None else band(score)
        confusion[levels[expected if expected is not None else 4]][levels[estimated]] += 1
        if expected is not None:
            pairs.setdefault((row["family"], row["language"]), {})[row["label"]] = row
            if score is not None:
                errors.append(abs(estimated - expected))
    groups = {"all": pairs.values()}
    for language in ("en", "zh-Hant-yue", "mixed"):
        groups[language] = [p for (_, local), p in pairs.items() if local == language]
    pair_results = {}
    for language, group in groups.items():
        assessed = [p for p in group if p["risk"]["score"] is not None and p["benign"]["score"] is not None]
        pair_results[language] = {
            "total": len(group), "both_scored": len(assessed),
            "risk_higher_raw": sum(p["risk"]["raw_score"] > p["benign"]["raw_score"] for p in group),
            "risk_higher_among_both_scored": sum(p["risk"]["score"] > p["benign"]["score"] for p in assessed),
        }
    return {"confusion": confusion, "pairs": pair_results,
            "scored_binary_mean_absolute_band_error": statistics.fmean(errors) if errors else None,
            "scored_binary_cases": len(errors),
            "all_cases_summary": summarize(rows)}


def score_file(args):
    # Validate the model snapshot before enabling any local model loader code.
    sys.path.insert(0, str(ROOT))
    import torch
    from weight_edit import apply_patch, load_model
    from run import write_json

    input_path = ROOT / "grounded/data/blind.jsonl" if args.replay else args.input
    cases, digest = read_cases(input_path)
    protocol = {"threads": 4}
    args.output.mkdir(parents=True, exist_ok=False)
    before = time.perf_counter()
    model, base_digest = load_model(args.snapshot, protocol, args.output)
    patch_digest = None
    if args.patch is not None:
        patch_digest = sha256(args.patch.read_bytes()).hexdigest()
        apply_patch(model.head.scorer, args.patch, base_digest)
    revision = json.loads((ROOT / "evidence/model-provenance.json").read_text())["revision"]
    tokens = model.tokenizer
    for q in RUBRIC["questions"].values():
        if len(tokens(q["instructions"], add_special_tokens=False)["input_ids"]) > 95:
            raise ValueError("Decision instructions may be truncated")
    results = []
    with torch.inference_mode():
        for start in range(0, len(cases), 6):
            batch = cases[start:start + 6]
            eligible = [r for r in batch if r["messages"] and context_fits(r["messages"])]
            replies = model.system_one_batch([
                ({"chat": row["messages"]}, RUBRIC["questions"]) for row in eligible
            ]) if eligible else []
            if len(replies) != len(eligible):
                raise ValueError("System One response count differs from the batch")
            responses = iter(replies)
            eligible_ids = {r["id"] for r in eligible}
            for index, row in enumerate(batch, start + 1):
                if row["id"] in eligible_ids:
                    result = assess(next(responses))
                else:
                    result = {"score": None, "review_reason": "insufficient_context" if not row["messages"] else "context_too_long",
                              "raw_score": None}
                result["conversation"] = f"C{index:03d}"
                if args.replay:
                    result.update({k: row[k] for k in ("id", "label", "family", "language")})
                    result["expected_band"] = (0 if row["label"] == "benign" else
                                               RUBRIC["replay_expected_risk_band_by_family"].get(row["family"]))
                results.append(result)
            if start % 30 == 0 or len(results) == len(cases):
                print(f"Scored {len(results)}/{len(cases)}", flush=True)
    report = {"schema": "igguard-d1-risk-v1", "model": MODEL, "revision": revision,
              "source": "published_case_demo" if args.replay else "local_research",
              "conversations": [{k: a[k] for k in ("conversation", "score", "review_reason")}
                                for a in results]}
    if patch_digest is not None:
        report["weight_patch_sha256"] = patch_digest
    write_json(args.output / "score-report.json", report)
    write_json(args.output / "summary.json", summarize(results))
    if args.replay:
        write_json(args.output / "replay-results.json", replay_metrics(results))
        with (args.output / "predictions.jsonl").open("w") as f:
            for assessment in results:
                f.write(json.dumps(assessment, allow_nan=False) + "\n")
    write_json(args.output / "run.json", {
        "model_revision": revision, "model_weights_sha256": base_digest,
        "weight_patch_sha256": patch_digest,
        "rubric_sha256": sha256((HERE / "rubric.json").read_bytes()).hexdigest(),
        "input_sha256": digest, "elapsed_seconds": time.perf_counter() - before,
        "mode": "published_case_replay" if args.replay else "local_research",
    })


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--replay", action="store_true")
    source.add_argument("--input", type=Path, help="Local JSONL file with one conversation per line")
    parser.add_argument("--snapshot", type=Path, required=True)
    parser.add_argument("--patch", type=Path, help="Optional safetensors edit for the pinned checkpoint")
    parser.add_argument("--output", type=Path, required=True)
    score_file(parser.parse_args())


if __name__ == "__main__":
    main()
