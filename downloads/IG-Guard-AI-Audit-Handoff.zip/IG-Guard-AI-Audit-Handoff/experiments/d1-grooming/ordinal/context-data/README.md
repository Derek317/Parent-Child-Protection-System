# Context and severity experiment

This experiment asks whether an exchange contains enough visible evidence for a
score and, when it does, whether d1 assigns the right severity. Each scenario
has low, potential, moderate, high and unresolved variants in English, Hong Kong
Cantonese and mixed Cantonese–English. Labels 0–3 refer to the existing ordinal
rubric. A null label means the visible evidence is insufficient. Source URLs
identify the incident or safeguarding context used for adaptation. Constructed
utterances and counterfactual endings are research fixtures. The new test
exchanges describe a teen discussing contact with someone they know. They
exercise detection of disclosures and reported pressure. Direct conversations
with a person initiating harmful contact need a separate evaluation.

## Evaluation protocol

1. Keep each source scenario, its translations and its variants in one split.
   Freeze the test dialogues before fitting. Fit, selection and test contain 60,
   45 and 60 exchanges from four, three and four source groups respectively.
   The selection and test dialogues share an author. The four test groups draw
   on sources used in the earlier replay. English and Cantonese variants are
   related, and mixed examples alternate languages between turns. Only speaker
   and message text enter d1. Keep the old 90-case replay as a regression check.
2. Compare the unmodified d1 checkpoint, the preceding weight patch and a new
   1,024-coefficient final-scorer edit on identical inputs. Hold the native
   questions, evidence checks and score thresholds fixed. Verify each model
   activation capture against d1's System One probabilities.
3. Fit 48 candidates. The grid uses two anchors (original and previous), with or
   without constraints on how scores should change between variants of the same
   scenario, four ridge penalties and three edit sizes. Select on a separate
   development split. Penalize false alerts above 10% of low and potential cases,
   any alert on a partial case, and fewer than two thirds of partial cases deferred.
   Among candidates with the same total excess count, prefer exact five-way
   agreement, then detection of moderate/high cases, fewer false alerts, correct
   high-risk calls and coverage of complete exchanges, in that order.
4. Freeze the patch before evaluating the test set. An alert means a retained
   score of at least 50. Report benign and potentially risky examples crossing
   this threshold separately. Report coverage on complete examples, deferral of
   partial examples, exact five-way agreement, severe cases and language counts.
   The class mix is balanced by design. These rates describe this challenge set.
5. Verify the parent demo through the regular offline scoring CLI. Also score
   the first two messages of each complete test exchange with the frozen edit.
   Compare coverage within the same conversation. Incomplete prefixes have no
   assigned severity in this comparison. The downloadable parent report includes
   every full test window, including abstentions.

## Reproduction

Run in `experiments/d1-grooming/ordinal` using the pinned Python environment and
verified local checkpoint from the [harness instructions](../README.md). Use new
feature and result directories. The cached tensors contain model representations
of the research examples and stay in the local working directory.

```bash
mkdir -p /tmp/d1-context-features
for split in fit selection; do
  python context_features.py --snapshot /path/to/snapshot --input "context-data/$split.jsonl" --output "/tmp/d1-context-features/$split.safetensors"
done
python context_fit.py --features /tmp/d1-context-features --output /tmp/d1-context-results
python context_features.py --snapshot /path/to/snapshot --input context-data/test.jsonl --output /tmp/d1-context-features/test.safetensors
python context_features.py --snapshot /path/to/snapshot --input ../grounded/data/blind.jsonl --output /tmp/d1-context-features/legacy.safetensors
for split in test legacy; do
  python context_fit.py --features /tmp/d1-context-features --output /tmp/d1-context-results --split "$split"
done
python context_demo.py --snapshot /path/to/snapshot --results /tmp/d1-context-results --work /tmp/d1-context-native
```
