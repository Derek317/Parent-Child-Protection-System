"""Replay frozen weights through the native CPU scorer and check the parent-facing export."""
import argparse
import csv
from hashlib import sha256
import json
from pathlib import Path

from context_fit import DATA
from run import write_json
from score import band, read_cases, score_file


def verify(args):
    rows, _ = read_cases(DATA / "test.jsonl")
    full = [{"id": r["id"], "messages": r["messages"]} for r in rows]
    short, prefix_ids, references = [], {}, []
    for row in rows:
        if row["level"] is None:
            continue
        prefix = row["messages"][:2]
        key = tuple((m["speaker"], m["text"]) for m in prefix)
        if key not in prefix_ids:
            prefix_ids[key] = len(short)
            short.append({"id": "prefix-" + row["id"], "messages": prefix})
        references.append(prefix_ids[key])
    args.work.mkdir(parents=True, exist_ok=False)
    inputs = args.work / "windows.jsonl"
    inputs.write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in full + short))
    patch = args.results / "d1-context-head.safetensors"
    freeze = json.loads((args.results / "selection.json").read_text())
    if sha256(patch.read_bytes()).hexdigest() != freeze["patch_sha256"]:
        raise ValueError("Patch differs from the frozen candidate")
    output = args.work / "native"
    score_file(argparse.Namespace(input=inputs, snapshot=args.snapshot, patch=patch, output=output, replay=False))
    report = json.loads((output / "score-report.json").read_text())
    native = report["conversations"]
    predictions = [json.loads(line) for line in (args.results / "test/edited.jsonl").read_text().splitlines()]
    for row, pred, actual in zip(rows, predictions, native[:len(rows)], strict=True):
        score = actual["score"]
        observed = None if score is None else band(score)
        if pred["id"] != row["id"] or observed != pred["predicted"] or actual["review_reason"] != pred["review_reason"]:
            raise ValueError("Native API and cached readout disagree")
        if score is not None and abs(score - pred["score"]) > 0.002:
            raise ValueError("Unexpected score drift")
    complete = [r for row, r in zip(rows, native[:len(rows)], strict=True) if row["level"] is not None]
    prefix_results = native[len(rows):]
    paired_prefixes = [prefix_results[i] for i in references]
    pairs = [(s["score"] is not None, f["score"] is not None) for s, f in zip(paired_prefixes, complete, strict=True)]
    write_json(args.results / "test/prefix-comparison.json", {
        "n": len(pairs), "unique_prefixes": len(short), "prefix_scored": sum(s for s, f in pairs), "full_scored": sum(f for s, f in pairs),
        "gained_score": pairs.count((False, True)), "lost_score": pairs.count((True, False)),
        "both_scored": pairs.count((True, True)), "both_deferred": pairs.count((False, False)),
    })
    report["conversations"] = native[:len(rows)]
    write_json(args.results / "test/score-report.json", report)
    write_case_review(args.results / "test/case-review.csv", rows, predictions, report["conversations"])


def write_case_review(path, rows, predictions, conversations):
    bands = {0: "Low", 1: "Potential", 2: "Moderate", 3: "High", None: "Review"}
    with path.open("w", newline="", encoding="utf-8-sig") as out:
        w = csv.writer(out, lineterminator="\n")
        w.writerow(["Report ID", "Case", "Language", "Reference", "d1 score", "d1 outcome", "Review reason",
                    "Adapted exchange", "Reference rationale", "Source"])
        for row, pred, actual in zip(rows, predictions, conversations, strict=True):
            chat = "\n".join(m["speaker"] + " · " + m["text"] for m in row["messages"])
            w.writerow([actual["conversation"], row["id"], row["language"], bands[row["level"]], actual["score"],
                        bands[pred["predicted"]], actual["review_reason"], chat, row["rationale"], row["source_url"]])


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("results", "work", "snapshot"):
        parser.add_argument("--" + arg, required=True, type=Path)
    verify(parser.parse_args())
