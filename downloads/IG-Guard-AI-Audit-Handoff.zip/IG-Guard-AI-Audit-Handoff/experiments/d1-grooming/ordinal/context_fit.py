"""Fit an ordinal d1 readout using within-topic contrasts, then evaluate a frozen edit."""
import argparse
from collections import Counter, defaultdict
from hashlib import sha256
import json
from pathlib import Path

from safetensors import safe_open
from safetensors.torch import load_file
import torch

from fit_scorer import LANGUAGES, fit_delta, targets, write_json
from score import HERE, RUBRIC, assess, band, read_cases
from weight_edit import TENSOR, write_patch

DATA = HERE / "context-data"
PREVIOUS = HERE / "weight-edit/d1-ordinal-head.safetensors"
LEVELS = (0, 1, 2, 3, None)


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def load_split(directory, split):
    source = HERE.parent / "grounded/data/blind.jsonl" if split == "legacy" else DATA / f"{split}.jsonl"
    rows, source_hash = read_cases(source)
    if split == "legacy":
        for row in rows:
            row["level"] = 0 if row["label"] == "benign" else RUBRIC["replay_expected_risk_band_by_family"].get(row["family"])
    else:
        groups = defaultdict(list)
        for row in rows:
            if row["level"] is not None and (type(row["level"]) is not int or row["level"] not in range(4)):
                raise ValueError("Invalid severity reference")
            if not row["rationale"].strip() or not row["source_url"].startswith("https://"):
                raise ValueError("Missing adaptation rationale or source")
            groups[row["family"], row["language"]].append(row["level"])
        if any(Counter(v) != Counter(LEVELS) for v in groups.values()):
            raise ValueError("Missing or repeated severity variant in a family/language group")
        for family in {row["family"] for row in rows}:
            if {lang for fam, lang in groups if fam == family} != set(LANGUAGES):
                raise ValueError("Missing family translation")
    with safe_open(directory / f"{split}.safetensors", framework="pt") as f:
        metadata = f.metadata()
        if metadata["data_sha256"] != source_hash or metadata["rubric_sha256"] != digest(HERE / "rubric.json"):
            raise ValueError("Input or rubric differs from captured features")
        severity, enough, base = (f.get_tensor(k) for k in ("severity", "enough", "base"))
    if severity.shape != (len(rows), 4, 1024) or enough.shape != (len(rows), 2, 1024):
        raise ValueError("Unexpected feature dimensions")
    return rows, severity, enough, base, metadata


def verify_separation(first, second):
    for field in ("id", "family", "incident"):
        if {r[field] for r in first} & {r[field] for r in second}:
            raise ValueError(f"Shared {field} between development and evaluation groups")
    def text_keys(rows):
        return {tuple(m["text"].strip().casefold() for m in r["messages"]) for r in rows}
    if text_keys(first) & text_keys(second):
        raise ValueError("Identical dialogue crosses splits")


def contrasts(rows, severity, enough):
    """Demand that the option logits change with the visible behavior in a matched scenario."""
    groups = defaultdict(dict)
    for index, row in enumerate(rows):
        groups[row["family"], row["language"]][row["level"]] = index
    x, y = [], []
    rubric_logits = -2.5 * (torch.arange(4)[:, None] - torch.arange(4)[None]).abs().float()
    rubric_logits -= rubric_logits.mean(dim=1, keepdim=True)
    for group in groups.values():
        for low, high in ((0, 1), (1, 2), (2, 3), (0, 3)):
            x.append(severity[group[high]] - severity[group[low]])
            y.append(rubric_logits[high] - rubric_logits[low])
        for level in range(4):
            x.append(enough[group[level]] - enough[group[None]])
            y.append(torch.tensor([-2.5, 2.5]))
    return torch.cat(x), torch.cat(y)


def predict(rows, severity, enough, weight):
    distributions = (severity @ weight).softmax(-1).tolist()
    contexts = (enough @ weight).softmax(-1)[:, 1].tolist()
    records = []
    for row, p, context in zip(rows, distributions, contexts, strict=True):
        result = assess({"answers": {
            "severity": {"type": "score", "score": sum(i * n for i, n in enumerate(p)),
                         "probabilities": {str(i): n for i, n in enumerate(p)}},
            "enough": {"type": "noul", "noul": context},
        }, "usage": {"output_tokens": 0}})
        records.append({**result, "id": row["id"], "language": row["language"], "family": row["family"],
                        "expected": row["level"], "predicted": None if result["score"] is None else band(result["score"])})
    return records


def metrics(records):
    confusion = [[0] * 5 for _ in LEVELS]
    for r in records:
        confusion[LEVELS.index(r["expected"])][LEVELS.index(r["predicted"])] += 1
    correct = sum(confusion[i][i] for i in range(5))
    return {"n": len(records), "exact": correct, "confusion": confusion,
            "complete_scored": sum(sum(row[:4]) for row in confusion[:4]),
            "complete": sum(sum(row) for row in confusion[:4]),
            "benign_alerts": sum(confusion[0][2:4]), "potential_alerts": sum(confusion[1][2:4]),
            "negative_total": sum(confusion[0]) + sum(confusion[1]),
            "risk_alerts": sum(sum(row[2:4]) for row in confusion[2:4]),
            "positive_total": sum(confusion[2]) + sum(confusion[3]),
            "high_exact": confusion[3][3], "high_total": sum(confusion[3]),
            "partial_deferred": confusion[4][4], "partial_total": sum(confusion[4]),
            "partial_alerts": sum(confusion[4][2:4]),
            "review_reasons": dict(Counter(r["review_reason"] for r in records if r["review_reason"]))}


def rank(m):
    # Every selection family contributes one example of each label per language.
    false = m["benign_alerts"] + m["potential_alerts"]
    excess = (max(0, false - m["negative_total"] // 10) + m["partial_alerts"]
              + max(0, (2 * m["partial_total"] + 2) // 3 - m["partial_deferred"]))
    return (-excess, m["exact"], m["risk_alerts"], -false, m["high_exact"], m["complete_scored"])


def fit(args):
    rows, s, e, base, meta = load_split(args.features, "fit")
    val, vs, ve, vbase, vmeta = load_split(args.features, "selection")
    if meta["base_sha256"] != vmeta["base_sha256"] or not torch.equal(base, vbase):
        raise ValueError("Fit and selection use different checkpoints")
    verify_separation(rows, val)
    previous = load_file(PREVIOUS)[TENSOR][0]
    x, y = targets(rows, s, e)
    dx, dy = contrasts(rows, s, e)
    args.output.mkdir(exist_ok=False, parents=True)
    candidates = []
    best_rank, best_weight, best_config = None, None, None
    for origin, anchor in (("original", base), ("previous", previous)):
        for paired in (False, True):
            features = torch.cat((x, dx)) if paired else x
            labels = torch.cat((y, dy)) if paired else y
            for ridge in (0.05, 0.3, 1, 5):
                delta = fit_delta(features, labels, anchor, ridge)
                for step in (0.6, 1, 1.6):
                    weight = anchor + delta * step
                    m = metrics(predict(val, vs, ve, weight))
                    config = {"anchor": origin, "paired": paired, "ridge": ridge, "step": step}
                    candidates.append({"config": config, "metrics": m})
                    if best_rank is None or rank(m) > best_rank:
                        best_weight, best_config, best_rank = weight, config, rank(m)
    patch = args.output / "d1-context-head.safetensors"
    write_patch(patch, best_weight[None], meta["base_sha256"])
    write_json(args.output / "selection.json", {
        "fit_sha256": meta["data_sha256"], "selection_sha256": vmeta["data_sha256"],
        "rubric_sha256": meta["rubric_sha256"], "base_sha256": meta["base_sha256"],
        "previous_sha256": digest(PREVIOUS), "patch_sha256": digest(patch), "chosen": best_config,
        "controls": {k: metrics(predict(val, vs, ve, w)) for k, w in (("original", base), ("previous", previous))},
        "candidates": candidates})
    print("Frozen", best_config, "rank", best_rank, "sha256", digest(patch))


def evaluate(args):
    freeze = json.loads((args.output / "selection.json").read_text())
    patch = args.output / "d1-context-head.safetensors"
    if digest(patch) != freeze["patch_sha256"] or digest(PREVIOUS) != freeze["previous_sha256"]:
        raise ValueError("Weight files differ from selection record")
    rows, s, e, base, meta = load_split(args.features, args.split)
    if args.split == "test":
        for split in ("fit", "selection"):
            development, fingerprint = read_cases(DATA / f"{split}.jsonl")
            if fingerprint != freeze[f"{split}_sha256"]:
                raise ValueError("Development records differ from selection")
            verify_separation(development, rows)
    if freeze["base_sha256"] != meta["base_sha256"] or freeze["rubric_sha256"] != meta["rubric_sha256"]:
        raise ValueError("Checkpoint or rubric mismatch")
    results = {"data_sha256": meta["data_sha256"]}
    output = args.output / args.split
    output.mkdir(exist_ok=False)
    for name, weight in (("original", base), ("previous", load_file(PREVIOUS)[TENSOR][0]),
                         ("edited", load_file(patch)[TENSOR][0])):
        records = predict(rows, s, e, weight)
        results[name] = {key: metrics([r for r in records if key == "all" or r["language"] == key])
                         for key in ("all", *LANGUAGES)}
        (output / f"{name}.jsonl").write_text("".join(json.dumps(r, allow_nan=False) + "\n" for r in records))
        print(name, results[name]["all"], flush=True)
    write_json(output / "comparison.json", results)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--features", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--split", choices=["test", "legacy"], help="Evaluate frozen weights on this split")
    args = parser.parse_args()
    torch.set_num_threads(2)
    (evaluate if args.split else fit)(args)
