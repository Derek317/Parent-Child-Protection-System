"""Capture verified d1 readout inputs once for a text-only research split."""
import argparse
from hashlib import sha256
from pathlib import Path

from safetensors.torch import save_file

from fit_scorer import capture, load_model
from score import HERE, context_fits, read_cases


def capture_file(snapshot, source, output):
    if output.exists():
        raise FileExistsError(output)
    rows, data_hash = read_cases(source)
    if not all(row["messages"] and context_fits(row["messages"]) for row in rows):
        raise ValueError("This evaluation expects nonempty windows within the scorer's size limit")
    model, base_hash = load_model(snapshot, {"threads": 4}, output.parent)
    features = {q: capture(model, rows, q) for q in ("severity", "enough")}
    features["base"] = model.head.scorer[3].weight[0].detach().cpu().contiguous()
    temporary = output.with_suffix(".partial")
    save_file(features, temporary, metadata={
        "data_sha256": data_hash, "base_sha256": base_hash,
        "rubric_sha256": sha256((HERE / "rubric.json").read_bytes()).hexdigest(),
    })
    temporary.replace(output)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("snapshot", "input", "output"):
        parser.add_argument("--" + arg, required=True, type=Path)
    args = parser.parse_args()
    capture_file(args.snapshot, args.input, args.output)
