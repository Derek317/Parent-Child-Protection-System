# d1 four-level replay

18 November 2026. We used the unedited pinned LiquidAI/d1-omni-600M weights and the
fixed [rubric](rubric.json). We replayed the 90 previously evaluated published-case
adaptations in English, Cantonese and mixed Cantonese–English. The new ordinal
reference levels describe visible behavior in those adaptations. They are author
judgments and were assigned before this run. The experiment uses the same cases
as the earlier binary evaluation, so this is a replay of a known dataset. No
conversation from a real family's device was used. [Sources and case design](../grounded/REPORT.md)

| Expected level | Low | Potential | Moderate | High | Needs review |
| --- | ---: | ---: | ---: | ---: | ---: |
| Low (36) | 1 | 0 | 1 | 0 | 34 |
| Potential (6) | 0 | 0 | 0 | 0 | 6 |
| Moderate (21) | 0 | 3 | 0 | 0 | 18 |
| High (9) | 0 | 0 | 0 | 0 | 9 |
| Insufficient context (18) | 3 | 1 | 0 | 0 | 14 |

**9 of 90 examples received a score.** The evidence check deferred 79 and the
level-confidence check deferred another two. English had 2/30 scored, Cantonese
4/30 and mixed Cantonese–English 3/30. The nine scored examples averaged 29.8,
with a maximum of 59.0. The maximum came from a benign adaptation. Four of the
18 intentionally partial exchanges received scores even though the reference
rubric calls for review. Those statistics apply to the benchmark only.
[Metrics](results/replay-results.json) · [Score report](results/score-report.json)

Before the review checks, the risky adaptation scored higher in 25 of 36 matched
pairs: 11/12 in English, 6/12 in Cantonese and 8/12 in mixed Cantonese–English.
Only one pair had both scores retained and the benign version scored higher in that
pair. No raw score reached 75, including any of the nine expected high-risk cases.
Relaxing the evidence gate would increase coverage while leaving the absence of
high scores and the overlap with benign cases. The replay gives no basis for
using this model's scores to drive family alerts. [Per-case scores](results/predictions.jsonl)

The full two-question replay took 181 seconds on the workspace CPU. The
provenance file records the checkpoint, input and rubric hashes. The preview
only imports the model's score report for manual review. [Run record](results/run.json)
