import unittest

from score import band, assess, summarize


def response(levels, enough=0.8):
    return {"answers": {
        "severity": {"type": "score", "score": sum(i * p for i, p in enumerate(levels)),
                     "probabilities": {str(i): p for i, p in enumerate(levels)}},
        "enough": {"type": "noul", "noul": enough}
    }, "usage": {"output_tokens": 0}}


class RiskScoringTest(unittest.TestCase):
    def test_cutoffs_are_half_open_and_high_includes_100(self):
        self.assertEqual([band(s) for s in (0, 24.99, 25, 49.99, 50, 74.99, 75, 100)],
                         [0, 0, 1, 1, 2, 2, 3, 3])

    def test_review_cannot_dilute_the_average(self):
        high = assess(response([0, 0, 0, 1]))
        low = assess(response([1, 0, 0, 0]))
        uncertain = assess(response([0.25] * 4))
        missing = assess(response([1, 0, 0, 0], enough=0.1))
        result = summarize([high, low, uncertain, missing])
        self.assertEqual((result["mean"], result["highest"], result["scored"], result["review"]),
                         (50.0, 100.0, 2, 2))
        self.assertIsNone(summarize([missing])["mean"])
        self.assertEqual((uncertain["review_reason"], missing["review_reason"]),
                         ("uncertain_score", "insufficient_context"))

    def test_rejects_malformed_score_distribution(self):
        with self.assertRaises(ValueError):
            assess(response([1, 0.5, 0, 0]))
