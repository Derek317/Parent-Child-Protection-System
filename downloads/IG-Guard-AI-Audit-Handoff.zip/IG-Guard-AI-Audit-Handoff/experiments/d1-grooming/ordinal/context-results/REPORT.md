# IG Guard conversation-scoring study

18 November 2026 · LiquidAI/d1-omni-600M · Experimental branch

This edit gave exact agreement on 12/60 new test cases, up from 7/60 for the
preceding edit. It scored one additional complete case. Low-risk alerts fell
from one to zero, while alerts across low, potential and unresolved cases rose
from one to three. It detected 3/24 moderate or high cases and assigned high
risk to 0/12. These results support using the file as a human-reviewed experiment.
Automatic parent alerts would miss most of the reference risk cases.

## Held-out test

Each of four scenarios has a low, potential, moderate, high and unresolved ending
in English, Cantonese and mixed chat. Every test exchange has six messages. For
example, versions of a charity-run conversation differ in whether the other person
accepts a boundary or repeatedly asks for location access. Only the visible exchange
goes into the model. A numeric score of 50 is the research alert threshold.
A deferral on a moderate or high case counts as a missed alert.

| Measure | Original d1 | Previous edit | New edit |
| --- | ---: | ---: | ---: |
| Complete exchanges given a numeric score | 3/48 | 23/48 | 24/48 |
| Unresolved exchanges deferred to review | 11/12 | 3/12 | 7/12 |
| Exact reference match, including review | 11/60 | 7/60 | 12/60 |
| Low cases scoring at least 50 | 0/12 | 1/12 | 0/12 |
| Potential cases scoring at least 50 | 0/12 | 0/12 | 2/12 |
| Unresolved cases scoring at least 50 | 0/12 | 0/12 | 1/12 |
| Moderate or high cases scoring at least 50 | 1/24 | 4/24 | 3/24 |
| High cases scoring at least 75 | 0/12 | 0/12 | 0/12 |

| Outcome on all 60 cases | Original d1 | Previous edit | New edit |
| --- | ---: | ---: | ---: |
| Numeric score | 4 | 32 | 29 |
| Insufficient context | 56 | 10 | 20 |
| Uncertain severity | 0 | 18 | 11 |

| Language | Complete scored | Exact, including review | Low alerted | Potential alerted | Moderate/high detected | High assigned high | Unresolved deferred |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| English | 9/16 | 2/20 | 0/4 | 0/4 | 1/8 | 0/4 | 1/4 |
| Cantonese | 4/16 | 4/20 | 0/4 | 1/4 | 0/8 | 0/4 | 4/4 |
| Mixed | 11/16 | 6/20 | 0/4 | 1/4 | 2/8 | 0/4 | 2/4 |

Case C028 illustrates what a missed alert looks like. In the English version,
a teen reports repeated location requests after setting a limit. The reference
is moderate, and the edit returns insufficient context. The unresolved version
of that scenario, C029, receives a low score of 24.2. On the Cantonese set the
new edit detected zero of eight moderate or high cases.

Each language has just four examples per reference level. The three language
versions share the same underlying scenarios. Results describe these examples,
and the scores are uncalibrated.

## Effect of supplying the rest of the conversation

With the new weights, the first two turns received scores for 24/48
paired comparisons. The complete six-turn versions received scores for
24/48. Adding the remaining turns produced a score in
7 exchanges and removed a score in 7.
The 48 comparisons share 12 distinct two-turn openings.
The short openings have no assigned severity. Some full six-turn windows also
warrant deferral because a reply or outcome is missing.
[Paired results](test/prefix-comparison.json)

## Replay of the original 90 demo cases

| Measure | Original d1 | Previous edit | New edit |
| --- | ---: | ---: | ---: |
| Complete exchanges given a numeric score | 5/72 | 45/72 | 44/72 |
| Unresolved exchanges deferred to review | 14/18 | 2/18 | 7/18 |
| Exact reference match, including review | 15/90 | 13/90 | 8/90 |
| Low cases scoring at least 50 | 1/36 | 1/36 | 1/36 |
| Potential cases scoring at least 50 | 0/6 | 0/6 | 0/6 |
| Unresolved cases scoring at least 50 | 0/18 | 0/18 | 0/18 |
| Moderate or high cases scoring at least 50 | 0/30 | 3/30 | 1/30 |
| High cases scoring at least 75 | 0/9 | 0/9 | 0/9 |

On this older demo, the original checkpoint returned insufficient context in
79 cases and uncertain severity in two. The previous edit returned those
reasons in 11 and 18 cases. The new edit returned them in 23 and 12 cases.
It deferred more genuinely unresolved examples than the previous edit, but
exact agreement dropped from 13 to eight and moderate/high detection from three
to one. All three versions flagged one of the 36 low-risk examples and none
correctly classified any of the nine high-risk examples as high.
[Replay results](legacy/comparison.json)

## How the weight edit was tested

The fit used 60 source-inspired examples from four scenario groups. A separate
45-example development set from three groups chose between 48 edits of the
final 1,024 scorer weights. The chosen edit started from the previous weights,
used differences between variants of the same scenario, a ridge penalty of 0.05
and an edit multiplier of 1. It gave exact agreement on 16/45 development
examples and detected 7/18 moderate or high cases. No development low or
potential cases scored at least 50. The task questions, review rules and
25/50/75 band boundaries stayed fixed. The selected weights were frozen
before evaluating the held-out cases or the old replay.
[Method and reproduction](../context-data/README.md) · [Selection results](selection.json)

The 60 held-out dialogues were fixed before fitting and are disjoint from the
current fit and selection groups. Their four underlying source groups appeared
in the earlier study. The selection and test adaptations share an author.
Each test exchange features a teen discussing events with someone they know.
This tests recognition of reported pressure or disclosures. Performance on direct
incoming messages remains an open question. The risk labels are research
judgments. No independently adjudicated family
conversations were tested. Earlier case reports and guidance informed these
synthetic exchanges. The CSV includes each source, scenario and label rationale.

The native CPU scorer loaded the patch and independently scored every held-out
case. All reported decisions matched the cached evaluation, with a tolerance
of 0.002 points for numeric scores. The Android debug app’s report parser accepted all 60 rows of the
resulting score-only JSON in a Robolectric test. The model ran on a CPU outside the phone. A second fit reproduced all 48
development results and the selected coefficients exactly.
[Native run for 60 cases and 12 distinct prefixes](test/native-run.json) · [Parent demo](test/score-report.json) · [Reviewer CSV](test/case-review.csv) · [Full test metrics](test/comparison.json)

The 1,024-weight replacement applies to the pinned checkpoint under the LFM Open
License. Its SHA-256 digest is `e504a4e916818e0ec6c783f43471b958a4362a90992bd4b22ea7d45067025630`.
[Weight file](d1-context-head.safetensors) · [License](LICENSE)
