# Follow-up weight edit for four-level d1 scoring

18 November 2026. This trial changed the 1,024 coefficients in d1's final shared
decision scorer. It uses the pinned LiquidAI/d1-omni-600M checkpoint, identical
questions, and the original review checks and score bands. The replay uses 90
previously evaluated case adaptations, so the results describe performance on a
known benchmark. [Original replay](../REPORT.md) · [Case sources](../../grounded/REPORT.md)

## Fitting and selection

We extracted the model's per-option activations and verified that applying the
original weights reproduced the System One probabilities. The fit regressed
centered option logits toward ordered severity targets and toward correct
sufficiency decisions. The 78 fit conversations and 48 selection conversations
come from disjoint incident groups. Each set also includes the first turn of
each benign pair as a partial exchange, yielding 117 and 72 examples respectively.
The development severity labels are research judgments. They include three
high-concern families, with the other concerning development cases at moderate.
[Fit code](../fit_scorer.py)

The selector compared 15 anchored ridge edits. It first checked for at most one
benign alert and zero partial-exchange alerts per language on the 72-example
selection set. Among candidates meeting that bound it maximized the worst-language
risk detection and then overall risk detection. It froze the selected edit before
the replay. The file is a 4,376-byte replacement tensor for the pinned checkpoint.
[Selection record](selection.json) · [Patch](d1-ordinal-head.safetensors) · [License](LICENSE)

## Results on the same 90 cases

An alert for this comparison means a retained score of 50 or higher. The debug
preview displays results for human review. Its score bands are experimental.

| Measure | Original | Edited |
| --- | ---: | ---: |
| Examples that received a score | 9/90 | 61/90 |
| Expected risk examples at the alert threshold | 0/36 | 3/36 |
| Benign examples at the alert threshold | 1/36 | 1/36 |
| Expected high-risk examples assigned high risk | 0/9 | 0/9 |
| Partial exchanges correctly sent to review | 14/18 | 2/18 |
| Exact match across four levels and review | 15/90 | 13/90 |
| Risk adaptation ranked above its matched benign adaptation before review checks | 25/36 | 24/36 |

The three edited risk alerts came from two English cases and one mixed-language
case. Cantonese produced zero risk alerts. All nine expected high-risk examples
stayed below the alert threshold or went to review. Of the 36 benign examples,
17 moved into the potentially risky band. At the chosen threshold the benign
false-alert count stayed the same. More numeric scores did not improve overall
agreement with the reference labels. [Edited confusion matrix](replay/replay-results.json) · [Per-case results](replay/predictions.jsonl)

The result supports retaining the weight edit as an optional offline research
candidate. The next controlled comparison needs new source families, with
realistic incomplete context and more independently rated severe and benign
examples. CPU replay and Android report import are separate processes.
[Reproduction commands](../README.md) · [Run record](replay/run.json)
