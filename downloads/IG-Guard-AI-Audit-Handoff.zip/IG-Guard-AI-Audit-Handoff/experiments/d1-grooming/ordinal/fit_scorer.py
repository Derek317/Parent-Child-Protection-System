"""Fit a single shared d1 decision tensor on development families."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys
import time

import torch
from safetensors.torch import save_file

from score import ROOT, RUBRIC, assess, band, read_cases

sys.path.insert(0, str(ROOT))
from run import write_json
from weight_edit import TENSOR, fit_delta, load_model

HIGH_FAMILIES = {"f04", "f09", "v02"}
LANGUAGES = ("en", "zh-Hant-yue", "mixed")
RIDGES = (0.05, 0.3, 1.0, 3.0, 10.0)
STEPS = (0.5, 1.0, 2.0)


def development_cases(split):
    rows, digest = read_cases(ROOT / f"grounded/data/{split}.jsonl")
    for row in rows:
        row["level"] = 0 if row["label"] == "benign" else 3 if row["family"] in HIGH_FAMILIES else 2
    fragments = [
        {**r, "id": r["id"] + "-opening", "messages": r["messages"][:1], "level": None}
        for r in rows if r["label"] == "benign"
    ]
    return rows + fragments, digest


@torch.inference_mode()
def capture(model, rows, name):
    """Reconstruct native distributions from final-layer inputs in API response order."""
    q = RUBRIC["questions"][name]
    options = 4 if name == "severity" else 2
    temperature = model.config.temperatures["score:3-5" if options == 4 else "noul:2"]
    final = model.head.scorer[3]
    features, pending = [], []
    hook = final.register_forward_pre_hook(lambda _, inputs: pending.append(inputs[0].cpu()))
    try:
        for start in range(0, len(rows), 8):
            replies = model.system_one_batch([
                ({"chat": r["messages"]}, {name: q}) for r in rows[start:start + 8]
            ])
            order = sorted(range(len(replies)), key=lambda i: replies[i]["usage"]["input_tokens"], reverse=True)
            captured = torch.cat(pending)
            pending.clear()
            if captured.shape[:2] != (len(replies), options):
                raise ValueError("Unexpected scorer activation shape")
            ordered = torch.empty_like(captured)
            ordered[order] = captured
            centered = (ordered - ordered.mean(dim=1, keepdim=True)) / temperature
            if options == 4:
                baseline = [[r["answers"][name]["probabilities"][str(i)] for i in range(4)] for r in replies]
                reconstructed = (centered @ final.weight[0]).softmax(-1)
            else:
                baseline = [r["answers"][name]["noul"] for r in replies]
                reconstructed = (centered @ final.weight[0]).softmax(-1)[:, 1]
            torch.testing.assert_close(reconstructed, torch.tensor(baseline), atol=5e-6, rtol=0)
            features.append(centered)
            if start % 32 == 0 or start + 8 >= len(rows):
                print(f"{name} activations {min(start+8, len(rows))}/{len(rows)}", flush=True)
    finally:
        hook.remove()
    return torch.cat(features)


def targets(rows, severity, enough):
    full = [i for i, r in enumerate(rows) if r["level"] is not None]
    levels = torch.tensor([rows[i]["level"] for i in full])
    ordered = -2.5 * (torch.arange(4)[None] - levels[:, None]).abs().float()
    ordered -= ordered.mean(dim=1, keepdim=True)
    yes = torch.tensor([1.25 if r["level"] is not None else -1.25 for r in rows])
    return torch.cat((severity[full].flatten(0, 1), enough.flatten(0, 1))), torch.cat(
        (ordered.flatten(), torch.stack((-yes, yes), dim=1).flatten()))


def development_metrics(rows, severity, enough, weight):
    distributions = (severity @ weight).softmax(-1).tolist()
    context = (enough @ weight).softmax(-1)[:, 1].tolist()
    predicted = []
    for p, c in zip(distributions, context, strict=True):
        expected = sum(i * n for i, n in enumerate(p))
        result = assess({"answers": {
            "severity": {"type": "score", "probabilities": {str(i): n for i, n in enumerate(p)}, "score": expected},
            "enough": {"type": "noul", "noul": c},
        }, "usage": {"output_tokens": 0}})
        predicted.append(None if result["score"] is None else band(result["score"]))
    stats = {}
    for language in ("all", *LANGUAGES):
        cases = [(r["level"], p) for r, p in zip(rows, predicted, strict=True)
                 if language == "all" or r["language"] == language]
        stats[language] = {
            "scored": sum(p is not None for _, p in cases),
            "risk_alerts": sum(level not in (0, None) and p in (2, 3) for level, p in cases),
            "benign_alerts": sum(level == 0 and p in (2, 3) for level, p in cases),
            "fragment_alerts": sum(level is None and p in (2, 3) for level, p in cases),
            "high_correct": sum(level == 3 and p == 3 for level, p in cases),
            "exact": sum(level == p for level, p in cases),
        }
    return stats


def rank(stats):
    all_cases = stats["all"]
    # Selection has eight examples per group and language of each of benign, risk, and partial.
    feasible = all(stats[g]["benign_alerts"] <= 1 and stats[g]["fragment_alerts"] == 0 for g in LANGUAGES)
    return (feasible, min(stats[g]["risk_alerts"] for g in LANGUAGES), all_cases["risk_alerts"],
            -all_cases["benign_alerts"], -all_cases["fragment_alerts"], all_cases["high_correct"], all_cases["exact"])


@torch.inference_mode()
def fit(args):
    start = time.perf_counter()
    args.output.mkdir(parents=True, exist_ok=False)
    train, fit_sha = development_cases("fit")
    select, selection_sha = development_cases("selection")
    if {r["incident"] for r in train} & {r["incident"] for r in select}:
        raise ValueError("Development splits share source incidents")
    model, base_sha = load_model(args.snapshot, {"threads": 4}, args.output)
    base = model.head.scorer[3].weight.detach()[0].cpu()
    fit_s = capture(model, train, "severity")
    fit_e = capture(model, train, "enough")
    x, y = targets(train, fit_s, fit_e)
    select_s = capture(model, select, "severity")
    select_e = capture(model, select, "enough")
    baseline = development_metrics(select, select_s, select_e, base)
    results = []
    for ridge in RIDGES:
        delta = fit_delta(x, y, base, ridge)
        for step in STEPS:
            weight = base + step * delta
            scores = development_metrics(select, select_s, select_e, weight)
            results.append((ridge, step, scores, weight))
    ridge, step, stats, winner = max(results, key=lambda entry: rank(entry[2]))
    patch = args.output / "d1-ordinal-head.safetensors"
    save_file({TENSOR: winner[None].contiguous()}, patch, metadata={
        "base_checkpoint_sha256": base_sha,
        "modification": "IG Guard ordinal final-scorer edit; LFM Open License v1.0",
    })
    write_json(args.output / "selection.json", {
        "tensor": TENSOR, "base_sha256": base_sha, "patch_sha256": sha256(patch.read_bytes()).hexdigest(),
        "fit_sha256": fit_sha, "selection_sha256": selection_sha,
        "rubric_sha256": sha256((Path(__file__).parent / "rubric.json").read_bytes()).hexdigest(),
        "high_families": sorted(HIGH_FAMILIES), "fit_count": len(train), "selection_count": len(select),
        "original": baseline, "chosen": {"ridge": ridge, "step": step, "metrics": stats},
        "candidates": [{"ridge": r, "step": s, "metrics": a} for r, s, a, _ in results],
        "seconds": time.perf_counter() - start,
    })
    print(f"Froze ridge={ridge}, step={step}, selection={stats['all']}", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--snapshot", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    fit(parser.parse_args())
