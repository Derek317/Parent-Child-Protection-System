import unittest

from context_fit import metrics, rank, verify_separation


def results(labels, outputs):
    return metrics([{"expected": y, "predicted": p, "review_reason": "insufficient_context" if p is None else None}
                    for y, p in zip(labels, outputs, strict=True)])


class ContextFitTests(unittest.TestCase):
    def test_denominators_include_unscored_conversations(self):
        m = results([0, 1, 2, 3, None], [2, 2, None, 3, 1])
        self.assertEqual((m["complete_scored"], m["complete"]), (3, 4))
        self.assertEqual((m["benign_alerts"], m["potential_alerts"], m["negative_total"]), (1, 1, 2))
        self.assertEqual((m["risk_alerts"], m["positive_total"]), (1, 2))
        self.assertEqual((m["exact"], m["partial_deferred"], m["partial_total"]), (1, 0, 1))

    def test_selection_penalizes_alerting_on_partial_data(self):
        labels = [0, 1, 2, 3, None] * 3
        good = results(labels, [0, 1, 2, None, None] * 3)
        risky = results(labels, [0, 1, 2, 3, 3] + labels[5:])
        self.assertGreater(risky["exact"], good["exact"])
        self.assertGreater(rank(good), rank(risky))

    def test_relabelled_duplicate_text_cannot_cross_splits(self):
        common = [{"speaker": "student", "text": "Can we use the library?"}]
        first = [{"id": "a", "family": "A", "incident": "1", "messages": common}]
        second = [{"id": "b", "family": "B", "incident": "2", "messages": common}]
        with self.assertRaisesRegex(ValueError, "dialogue"):
            verify_separation(first, second)


if __name__ == "__main__":
    unittest.main()
