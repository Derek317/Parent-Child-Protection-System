package app.family.igguard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class RiskScoreReportTest {
    private fun parse(rows: String, patch: String? = null) = RiskScoreReport.read(
        """
        {"schema":"igguard-d1-risk-v1","model":"LiquidAI/d1-omni-600M",
         "revision":"02b55d7076f15129e59ab3f94783f32c4b088674",
         "source":"published_case_demo",${patch?.let { "\"weight_patch_sha256\":\"$it\"," }.orEmpty()} "conversations":[$rows]}
        """.trimIndent().byteInputStream()
    )

    @Test fun realZeroCountsAndUnscoredConversationsDoNotDiluteTheAverage() {
        val digest = "a".repeat(64)
        val report = parse("""
            {"conversation":"C001","score":0,"review_reason":null},
            {"conversation":"C002","score":100,"review_reason":null},
            {"conversation":"C003","score":null,"review_reason":"insufficient_context"}
        """, digest)
        assertEquals(digest, report.weightPatch)
        assertEquals(2, report.scores.size)
        assertEquals(1, report.reviewCount)
        assertEquals(50.0, report.mean)
        assertEquals(100.0, report.highest)
        assertEquals(mapOf(RiskBand.LOW to 1, RiskBand.HIGH to 1), report.counts)
    }

    @Test fun allUnscoredConversationsYieldNoAverageOrHighest() {
        val report = parse("""{"conversation":"C001","score":null,"review_reason":"uncertain_score"}""")
        assertNull(report.mean)
        assertNull(report.highest)
        assertEquals(1, report.reviewCount)
    }

    @Test fun exactCutoffsBelongToTheHigherBand() {
        listOf(24.999 to RiskBand.LOW, 25.0 to RiskBand.POTENTIAL, 49.999 to RiskBand.POTENTIAL,
            50.0 to RiskBand.MODERATE, 74.999 to RiskBand.MODERATE, 75.0 to RiskBand.HIGH)
            .forEach { (value, expected) -> assertEquals(expected, RiskBand.forScore(value)) }
    }

    @Test fun rejectsInvalidScoresDuplicateIdsAndTranscriptFields() {
        val valid = """{"conversation":"C001","score":50,"review_reason":null}"""
        for (score in listOf("-0.1", "101", "\"50\"", "true", "null")) {
            assertThrows(Exception::class.java) { parse(valid.replace("50", score)) }
        }
        assertThrows(Exception::class.java) { parse("$valid,$valid") }
        assertThrows(Exception::class.java) { parse(valid.replace("\"score\":50", "\"score\":50,\"score\":50")) }
        assertThrows(Exception::class.java) { parse(valid.dropLast(1) + ""","text":"private chat"}""") }
    }
}
