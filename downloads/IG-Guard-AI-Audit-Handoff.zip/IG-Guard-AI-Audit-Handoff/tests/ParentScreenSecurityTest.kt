package app.family.igguard

import android.app.Activity
import android.app.Application
import android.content.Intent
import android.net.Uri
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowDialog
import org.robolectric.shadows.ShadowLooper
import java.util.concurrent.atomic.AtomicInteger

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28])
class ParentScreenSecurityTest {
    private val ctx: Application get()=RuntimeEnvironment.getApplication()
    private fun all(v:View):List<View> = listOf(v)+if(v is ViewGroup)(0 until v.childCount).flatMap{all(v.getChildAt(it))}else emptyList()
    @Before fun reset() {
        ParentUiAuthFixture.autoApprove=false
        LocalVault.preferences(ctx).edit().clear().commit()
        GuardEngine.setRole(ctx,"parent")
    }
    @Test fun parentUiRequiresAuthenticationAndPreventsScreenCapture() {
        val c=Robolectric.buildActivity(MainActivity::class.java).setup();val a=c.get()
        try {
            assertTrue(a.window.attributes.flags and WindowManager.LayoutParams.FLAG_SECURE != 0)
            assertTrue(all(a.window.decorView).any{it.tag=="parent_privacy_lock"})
            assertTrue(GuardEngine.transferAllowed(ctx))
        } finally {c.pause().stop().destroy()}
    }
    @Test fun parentNavigationStateSurvivesRotationWithoutPlaintextInSavedBundle() {
        val c=Robolectric.buildActivity(MainActivity::class.java).setup();val a=c.get()
        val state=android.os.Bundle()
        try {
            val access=MainActivity::class.java.getDeclaredField("parentAccess").apply{isAccessible=true}.get(a) as ParentAccessSession
            access.authenticated(GuardEngine.captureRelaySession(ctx))
            MainActivity::class.java.getDeclaredField("evidenceSearch").apply{isAccessible=true}.set(a,"private-search-marker")
            c.saveInstanceState(state)
            assertFalse(state.toString().contains("private-search-marker"))
        } finally {c.pause().stop().destroy()}
        val restored=Robolectric.buildActivity(MainActivity::class.java).setup(state)
        try {
            assertEquals("private-search-marker",MainActivity::class.java.getDeclaredField("evidenceSearch").apply{isAccessible=true}.get(restored.get()))
            assertTrue(all(restored.get().window.decorView).any{it.tag=="parent_privacy_lock"})
        } finally {restored.pause().stop().destroy()}
    }
    @Test fun cancelledOrStaleAuthenticationCannotUnlockCurrentFamily() {
        val c=Robolectric.buildActivity(MainActivity::class.java).setup();val a=c.get()
        try {
            val field=MainActivity::class.java.getDeclaredField("parentAuthSession").apply{isAccessible=true}
            val complete=MainActivity::class.java.getDeclaredMethod("completeParentAuthentication",Boolean::class.javaPrimitiveType).apply{isAccessible=true}
            field.set(a,GuardEngine.captureRelaySession(ctx));complete.invoke(a,false)
            assertTrue(all(a.window.decorView).any{it.tag=="parent_privacy_lock"})
            field.set(a,GuardEngine.captureRelaySession(ctx));GuardEngine.setFamilyToken(ctx,java.util.UUID.randomUUID().toString());complete.invoke(a,true)
            assertTrue(all(a.window.decorView).any{it.tag=="parent_privacy_lock"})
        } finally {c.pause().stop().destroy()}
    }
    @Test fun staleParentButtonCannotRevealSecretsAfterBackground() {
        val c=Robolectric.buildActivity(MainActivity::class.java).setup();val a=c.get()
        try {
            val access=MainActivity::class.java.getDeclaredField("parentAccess").apply{isAccessible=true}.get(a) as ParentAccessSession
            access.authenticated(GuardEngine.captureRelaySession(ctx))
            MainActivity::class.java.getDeclaredMethod("renderUi",Boolean::class.javaPrimitiveType).apply{isAccessible=true}.invoke(a,false)
            c.pause()
            assertFalse(access.isUnlocked(GuardEngine.captureRelaySession(ctx)))
            assertTrue(all(a.window.decorView).any{it.tag=="parent_privacy_lock"})
            assertTrue(GuardEngine.transferAllowed(ctx))
        } finally {c.stop().destroy()}
    }

    @Test fun pickedRiskReportRequiresReauthenticationAndSummarizesOnlyScoredConversations() {
        val c = Robolectric.buildActivity(MainActivity::class.java).setup()
        val a = c.get()
        fun unlock() {
            val session = MainActivity::class.java.getDeclaredField("parentAuthSession").apply { isAccessible = true }
            session.set(a, GuardEngine.captureRelaySession(ctx))
            MainActivity::class.java.getDeclaredMethod("completeParentAuthentication", Boolean::class.javaPrimitiveType)
                .apply { isAccessible = true }.invoke(a, true)
        }
        fun riskRow() = all(a.window.decorView).singleOrNull {
            it.isClickable && it.contentDescription?.startsWith("對話風險評分（試驗）") == true
        }
        val uri = Uri.parse("content://test/score-report.json")
        val reads = AtomicInteger()
        shadowOf(a.contentResolver).registerInputStreamSupplier(uri) {
            reads.incrementAndGet()
            """
            {"schema":"igguard-d1-risk-v1","model":"LiquidAI/d1-omni-600M",
             "revision":"02b55d7076f15129e59ab3f94783f32c4b088674","source":"published_case_demo",
             "conversations":[{"conversation":"C001","score":0,"review_reason":null},
             {"conversation":"C002","score":96,"review_reason":null},
             {"conversation":"C003","score":null,"review_reason":"insufficient_context"}]}
            """.trimIndent().byteInputStream()
        }
        try {
            assertNull(riskRow())
            unlock()
            MainActivity::class.java.getDeclaredMethod("navigateTo", String::class.java)
                .apply { isAccessible = true }.invoke(a, "overview")
            riskRow()!!.performClick()
            val sheet = ShadowDialog.getLatestDialog()
            all(sheet.window!!.decorView).filterIsInstance<Button>().single { it.text == "選擇評分檔案" }.performClick()
            val request = shadowOf(a).nextStartedActivityForResult
            assertEquals(Intent.ACTION_OPEN_DOCUMENT, request.intent.action)
            c.pause()
            assertFalse(sheet.isShowing)
            shadowOf(a).receiveResult(request.intent, Activity.RESULT_OK, Intent().setData(uri))
            c.resume()
            assertNull(riskRow())
            assertEquals(0, reads.get())
            unlock()
            val deadline = System.nanoTime() + 5_000_000_000L
            var text = ""
            while (!text.contains("平均") && System.nanoTime() < deadline) {
                ShadowLooper.idleMainLooper()
                text = all(ShadowDialog.getLatestDialog().window!!.decorView).filterIsInstance<TextView>()
                    .joinToString("\n") { it.text }
                if (!text.contains("平均")) Thread.sleep(5)
            }
            assertEquals(1, reads.get())
            assertTrue(text, text.contains("匯入報告 · 來源未驗證"))
            assertTrue(text, text.contains("已評分 2 / 3 段 · 待覆核 1 段"))
            assertTrue(text, text.contains("平均 48.0 / 100 · 潛在風險"))
            assertTrue(text, text.contains("最高 96.0 / 100 · 高風險"))
            assertTrue(text, text.contains("高風險（75–100） · 1 段"))
            assertTrue(ShadowDialog.getLatestDialog().window!!.attributes.flags and WindowManager.LayoutParams.FLAG_SECURE != 0)
            GuardEngine.setFamilyToken(ctx, java.util.UUID.randomUUID().toString())
            unlock()
            riskRow()!!.performClick()
            assertFalse(all(ShadowDialog.getLatestDialog().window!!.decorView).filterIsInstance<TextView>()
                .any { it.text.contains("96.0 / 100") })
        } finally { c.pause().stop().destroy() }
    }
}
