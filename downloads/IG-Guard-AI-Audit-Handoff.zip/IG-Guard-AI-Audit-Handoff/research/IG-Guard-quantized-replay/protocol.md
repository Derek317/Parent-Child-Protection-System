# Compressed model replay protocol

Replay the existing published-source adaptation benchmark with 36 risk, 36 benign
and 18 insufficient-context examples. The split and labels are frozen. Each
English, Cantonese and mixed-language group has 12 risk and 12 benign examples.
The original binary gate calls for at least 80% recall and at most 20% false alerts
overall, plus 70% recall and at most 30% false alerts in each language. Partial
cases are counted separately against the 0.35–0.65 review band.

Run the official text-only d1-omni-600M Q8_0 release and the community
Qwen3-Embedding-0.6B Q4_K_M using pinned llama.cpp build b12503 on the host
CPU. Download and verify the already-quantized artifacts before inference.
The servers listen on loopback. Only synthetic case messages go to the runtime.

With d1, use the frozen original and context-focused binary questions at 0.5.
Also replay the ordinal questions with the existing evidence and severity
confidence thresholds and 25, 50 and 75 bands. Compare to the saved full-precision
outputs. Different runtimes may cause some of the measured change. No extra
quantization, weight edits or test-set threshold fitting.

The Qwen embedding model produces a vector. Fit one ridge classifier to its
normalized output using the original 78 development examples with targets of
-2 and +2, an unpenalized intercept and a ridge penalty of 0.3 times the mean
Gram diagonal. Convert the readout to a 0–1 score by sigmoid, then pick one
threshold on the existing 48-example development selection split using the
original gate and ranking procedure. Freeze that threshold and weight digest
before opening the held-out file for Qwen inference. Report the original 0.5
cutoff too. This tests quantized embeddings plus a local classifier. No Qwen
model weights are changed. Timings measure the Linux host, including local API
overhead.
