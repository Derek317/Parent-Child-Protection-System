# IG Guard replay with compressed models

Both models processed all 90 frozen conversations with no request errors.
The run used pre-quantized files and a Linux CPU. The official d1 Q8 text GGUF
weighs 407,207,584 bytes. The Qwen Q4 search GGUF weighs 396,475,040 bytes.
Both matched the publishers’ SHA-256 digests before inference.

## Binary gate

| Configuration | Risk caught | Benign flagged | Partial examples in review band | Benchmark gate |
| --- | ---: | ---: | ---: | --- |
| d1 F32 · original question | 32/36 | 29/36 | 6/18 | Fail |
| d1 Q8 · original question | 32/36 | 30/36 | 6/18 | Fail |
| d1 F32 · context question | 1/36 | 0/36 | 0/18 | Fail |
| d1 Q8 · context question | 1/36 | 0/36 | 0/18 | Fail |
| Qwen Q4 + linear classifier · 0.5 cutoff | 24/36 | 20/36 | 13/18 | Fail |
| Qwen Q4 + linear classifier · development cutoff | 1/36 | 0/36 | 13/18 | Fail |

| Language | Qwen Q4 development cutoff, caught / false | d1 Q8 original question, caught / false | d1 Q8 context question, caught / false |
| --- | --- | --- | --- |
| English | 0/12 · 0/12 | 11/12 · 10/12 | 0/12 · 0/12 |
| Cantonese | 0/12 · 0/12 | 10/12 · 10/12 | 0/12 · 0/12 |
| Mixed | 1/12 · 0/12 | 11/12 · 10/12 | 1/12 · 0/12 |

The original gate required 80% risk recall and at most 20% benign false alerts
overall. Each language had to meet 70% recall and at most 30% false alerts.
In these samples that means at least 29 of 36 risk cases with at most 7 false
alerts overall, and at least 9 of 12 risk cases with at most 3 false alerts per
language. The review band counts are separate and exclude partial examples from
recall and false-alert denominators.

Qwen produced one 1,024-value embedding per conversation. A small local
ridge classifier produced the risk score after fitting only the 78 labeled
development examples. Its cutoff of 0.879520 was frozen
using the separate 48-example selection split. No benchmark case or reference
label entered training. The classifier changes the system used to score chats
and shares the original Qwen weights. [Qwen selection and cutoff](qwen/frozen.json)

## Ordinal report scoring

| Measure | d1 F32 | d1 Q8 |
| --- | ---: | ---: |
| Complete conversations scored | 5/72 | 2/72 |
| Exact band or review decision | 15/90 | 15/90 |
| Moderate/high at 50+ | 0/30 | 0/30 |
| Low risk at 50+ | 1/36 | 1/36 |
| Unresolved conversations deferred | 14/18 | 15/18 |

The Q8 artifact ran through llama.cpp. The F32 control comes from the existing
PyTorch replay. Changes can arise from the runtime and text encoding as well as
quantization. The 90 cases are constructed adaptations of safeguarding reports.
This run measures behavior on the frozen replay. Live-chat performance,
battery use and latency on Android remain unverified.

The first d1 run stopped before it wrote its results. The reported d1 run
replayed all 90 cases from the start with per-case checkpoints. It sent up to
four requests in parallel and completed in
537.2 seconds on the host CPU.
The Qwen test embeddings took 61.4 seconds
after fitting. Each d1 case asked four questions. The workloads differ.

[Case-by-case spreadsheet](case-review.csv) · [d1 metrics](d1/metrics.json) · [Qwen metrics](qwen/metrics.json) · [Protocol](protocol.md) · [Pinned artifact hashes](artifacts.json)
