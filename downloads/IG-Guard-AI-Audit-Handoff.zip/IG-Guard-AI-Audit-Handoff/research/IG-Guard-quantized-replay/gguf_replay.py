"""Replay two quantized models against the original 90 IG Guard cases."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import json
import math
from pathlib import Path
import statistics
import sys
import time
from urllib.request import Request, urlopen

PINNED_INPUTS = {
    "fit": "c6dd23f395cf17f49b3e542bdb3aa706b9b1bc759d40edf5d90a71ee813fc049",
    "selection": "8fe2602d35cce24b86794259eed6bc3871f80361eba63201f919db2ba0ec9c7a",
    "blind": "4fcf4a33536006a92512426533cb2eadcce1d4717caa6a58cbd06d5fdc934be1",
}
ARTIFACTS = {
    "d1": "d1-omni-600M-Q8_0.gguf",
    "qwen": "Qwen3-Embedding-0.6B.Q4_K_M.gguf",
}


def file_hash(path):
    return sha256(path.read_bytes()).hexdigest()


def post(port, path, payload, expected):
    request = Request(f"http://127.0.0.1:{port}/v1/{path}",
                      data=json.dumps(payload, ensure_ascii=False).encode(),
                      headers={"Content-Type": "application/json"})
    with urlopen(request, timeout=120) as response:
        body = json.load(response)
    if body["model"] != expected:
        raise ValueError("Local endpoint loaded an unexpected model")
    return body


def read_rows(root, name):
    from grounded_eval import read_split
    if file_hash(root / f"{name}.jsonl") != PINNED_INPUTS[name]:
        raise ValueError(f"Unexpected {name} file")
    return read_split(root, name)


def jsonl(path, rows):
    with path.open("w") as file:
        for row in rows:
            file.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")


def binary_results(rows, scores, cutoff, protocol):
    from grounded_eval import development_summary
    from weight_edit import gate
    result = development_summary(rows, scores, cutoff)
    return {"cutoff": cutoff, **result, "gate": gate(result["binary"], protocol)}


def timings(seconds):
    return {"total_seconds": sum(seconds), "p50_seconds": statistics.median(seconds),
            "p95_seconds": sorted(seconds)[math.ceil(len(seconds) * .95) - 1]}


def d1(args, protocol):
    from score import RUBRIC, assess, band, probability
    from context_fit import LANGUAGES, metrics
    from run import write_json
    root = args.root
    rows = read_rows(root / "grounded/data", "blind")
    questions = {**RUBRIC["questions"],
                 "binary_original": json.loads((root / "questions.json").read_text())["risk"],
                 "binary_context": json.loads((root / "grounded/context-question.json").read_text())["risk"]}
    def infer(row):
        state = {"chat": row["messages"]}
        started = time.perf_counter()
        response = post(args.port, "systemone", {"state": state, "questions": questions}, ARTIFACTS["d1"])
        answers = response["answers"]
        if set(answers) != set(questions) or any(answers[k]["type"] != "noul" for k in ("binary_original", "binary_context")):
            raise ValueError("System One returned the wrong questions or types")
        ordinal = assess(response)
        expected = 0 if row["label"] == "benign" else RUBRIC["replay_expected_risk_band_by_family"].get(row["family"])
        return {**ordinal, **{k: row[k] for k in ("id", "language", "family", "label")},
                "expected": expected, "predicted": None if ordinal["score"] is None else band(ordinal["score"]),
                "binary_original": probability(answers["binary_original"]["noul"]),
                "binary_context": probability(answers["binary_context"]["noul"]),
                "input_tokens": response["usage"]["input_tokens"], "seconds": time.perf_counter() - started}

    record = args.output / "predictions.jsonl"
    predictions = [json.loads(s) for s in record.read_text().splitlines()] if record.exists() else []
    if [r["id"] for r in predictions] != [r["id"] for r in rows[:len(predictions)]]:
        raise ValueError("Existing predictions do not match the frozen dataset prefix")
    start = time.perf_counter()
    with ThreadPoolExecutor(max_workers=4) as pool, record.open("a") as stream:
        for row in pool.map(infer, rows[len(predictions):]):
            stream.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
            stream.flush()
            predictions.append(row)
            if len(predictions) % 15 == 0:
                print(f"d1 {len(predictions)}/{len(rows)}", flush=True)
    timing = timings([p["seconds"] for p in predictions])
    timing["last_invocation_wall_seconds"] = time.perf_counter() - start
    result = {"input_sha256": PINNED_INPUTS["blind"], "rubric_sha256": file_hash(root/"ordinal/rubric.json"),
              "timing": timing, "ordinal": {
        key: metrics([r for r in predictions if key == "all" or r["language"] == key])
        for key in ("all", *LANGUAGES)}}
    for key in ("binary_original", "binary_context"):
        result[key] = binary_results(rows, [r[key] for r in predictions], protocol["binary_threshold"], protocol)
    write_json(args.output / "metrics.json", result)


def embed(port, rows):
    import torch
    samples, times = [], []
    for offset in range(0, len(rows), 6):
        batch = rows[offset:offset + 6]
        inputs = [json.dumps({"chat": r["messages"]}, ensure_ascii=False) for r in batch]
        start = time.perf_counter()
        response = post(port, "embeddings", {"input": inputs}, ARTIFACTS["qwen"])
        times.append((time.perf_counter() - start) / len(batch))
        entries = sorted(response["data"], key=lambda r: r["index"])
        if [e["index"] for e in entries] != list(range(len(batch))):
            raise ValueError("Embedding response is missing input indices")
        samples.extend(e["embedding"] for e in entries)
        if (offset+6) % 24 == 0 or offset + 6 >= len(rows):
            print(f"Qwen embedding {min(offset+6,len(rows))}/{len(rows)}", flush=True)
    x = torch.tensor(samples, dtype=torch.float64)
    if x.shape != (len(rows), 1024) or not torch.isfinite(x).all() or not (x.norm(dim=1) > 0).all():
        raise ValueError("Expected one finite nonzero 1024-element embedding per conversation")
    return torch.nn.functional.normalize(x), times


def qwen(args, protocol):
    import torch
    from safetensors.torch import save_file
    from grounded_eval import validate_disjoint
    from run import write_json
    from weight_edit import rank

    torch.set_num_threads(1)
    data = args.root / "grounded/data"
    fit, selection = [read_rows(data, name) for name in ("fit", "selection")]
    validate_disjoint({"fit": fit, "selection": selection})
    x, _ = embed(args.port, fit)
    xx = x - x.mean(0)
    y = torch.tensor([2.0 if r["label"] == "risk" else -2.0 for r in fit], dtype=x.dtype)
    gram = xx @ xx.T
    gram.diagonal().add_(.3 * gram.diagonal().mean())
    weight = xx.T @ torch.linalg.solve(gram, y - y.mean())
    bias = y.mean() - x.mean(0) @ weight
    val, _ = embed(args.port, selection)
    scores = torch.sigmoid(val @ weight + bias).tolist()
    thresholds = sorted({0.5, *scores, math.nextafter(max(scores), math.inf)})
    best = max((binary_results(selection, scores, t, protocol) for t in thresholds),
               key=lambda r: (*rank(r["binary"], protocol), -abs(r["cutoff"] - 0.5)))
    readout = args.output/"classifier.safetensors"
    save_file({"weight": weight, "bias": bias.contiguous()}, readout)
    write_json(args.output/"frozen.json", {"method": "L2-normalized Qwen embedding plus ridge classifier",
               "ridge_fraction": 0.3, "classifier_sha256": file_hash(readout),
               "fit_sha256": PINNED_INPUTS["fit"], "selection_sha256": PINNED_INPUTS["selection"],
               "blind_sha256": PINNED_INPUTS["blind"], "selection": best})
    print(f"Qwen cutoff frozen on development split: {best['cutoff']:.6f}", flush=True)
    blind = read_rows(data, "blind")
    validate_disjoint({"fit": fit, "selection": selection, "blind": blind})
    test, seconds = embed(args.port, blind)
    scores = torch.sigmoid(test @ weight + bias).tolist()
    jsonl(args.output/"predictions.jsonl", [
        {**{k:r[k] for k in ("id","label","language","family")}, "score": s, "risk": s >= best["cutoff"]}
        for r,s in zip(blind,scores,strict=True)])
    write_json(args.output/"metrics.json", {
        "input_sha256": PINNED_INPUTS["blind"], "tuned": binary_results(blind,scores,best["cutoff"],protocol),
        "fixed": binary_results(blind,scores,0.5,protocol),
        "timing_note": "p50/p95 use batch-average per case; total counts each batch once",
        "timing": {**timings(seconds), "total_seconds": sum(t*min(6,len(blind)-6*i) for i,t in enumerate(seconds))}
    })


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--backend", choices=("d1", "qwen"), required=True)
    parser.add_argument("--port", type=int, required=True)
    for name in ("root", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    sys.path[:0] = [str(args.root/"ordinal"), str(args.root/"grounded"), str(args.root)]
    args.output.mkdir(parents=True, exist_ok=(args.backend == "d1"))
    protocol = json.loads((args.root/"weight-protocol.json").read_text())
    (d1 if args.backend == "d1" else qwen)(args, protocol)
