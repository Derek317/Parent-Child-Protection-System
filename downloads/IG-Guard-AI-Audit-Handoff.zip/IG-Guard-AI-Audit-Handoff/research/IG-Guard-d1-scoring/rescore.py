"""Use an experimental severity readout with the current d1 evidence decision."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys

from safetensors import safe_open
import torch

from spike import evaluate_probabilities


def report(model, revision, weight_digest, results):
    return {"schema": "igguard-d1-risk-v1", "model": model, "revision": revision, "source": "local_research",
            "weight_patch_sha256": weight_digest,
            "conversations": [{"conversation": f"C{i:03d}", "score": row["score"], "review_reason": row["review_reason"]}
                              for i, row in enumerate(results, start=1)]}


def recover_uncertain(baseline, second):
    """Recover a moderate/high score only when both readouts support it."""
    if (baseline["review_reason"] == "uncertain_score" and baseline["raw_score"] >= 50
            and second["score"] is not None and second["score"] >= 50):
        from score import band

        score = min(baseline["raw_score"], second["score"])
        return {**second, "score": score, "predicted": band(score)}
    return baseline


def load_tensors(path, metadata, shapes):
    with safe_open(str(path), framework="pt") as f:
        if set(f.keys()) != set(shapes) or any((f.metadata() or {}).get(k) != v for k, v in metadata.items()):
            raise ValueError(f"Unexpected readout or checkpoint at {path}")
        values = {key: f.get_tensor(key) for key in shapes}
    if any(t.shape != shapes[key] or t.dtype != torch.float32 or not torch.isfinite(t).all()
           for key, t in values.items()):
        raise ValueError(f"Invalid readout tensor at {path}")
    return values


def run(args):
    sys.path.insert(0, str(args.ordinal))
    from fit_scorer import capture, load_model
    from score import ROOT, MODEL, context_fits, read_cases
    from weight_edit import TENSOR
    from run import write_json

    out = args.output
    out.mkdir(parents=True, exist_ok=False)
    records, _ = read_cases(args.input)
    current = args.ordinal / "context-results/d1-context-head.safetensors"
    checkpoint = json.loads((ROOT / "evidence/model-provenance.json").read_text())
    digest = checkpoint["files"]["model.safetensors"]["sha256"]
    rubric_digest = sha256((args.ordinal / "rubric.json").read_bytes()).hexdigest()
    patch_digest = sha256(current.read_bytes()).hexdigest()
    research_digest = sha256(args.readout.read_bytes()).hexdigest()
    heads = load_tensors(args.readout, {"base_sha256": digest, "rubric_sha256": rubric_digest,
                                      "current_edit_sha256": patch_digest}, {"weight": (4096, 4), "bias": (4,)})
    existing = load_tensors(current, {"base_checkpoint_sha256": digest}, {TENSOR: (1, 1024)})[TENSOR][0]

    predictions = {}
    baseline, alternate = [], []
    eligible = [r for r in records if r["messages"] and context_fits(r["messages"])]
    if eligible:
        model, actual_digest = load_model(args.snapshot, {"threads": 4}, out)
        if actual_digest != digest:
            raise ValueError("Unexpected d1 checkpoint")
        s = capture(model, eligible, "severity")
        e = capture(model, eligible, "enough")
        levels = (s.flatten(1) @ heads["weight"] + heads["bias"]).softmax(-1)
        evidence = (e @ existing).softmax(-1)[:, 1]
        # The normal input format requires id and messages. Reference labels are optional.
        for row in eligible:
            row.setdefault("family", None)
            row.setdefault("language", None)
            row.setdefault("level", None)
        alternate = evaluate_probabilities(eligible, levels, evidence)
        baseline = evaluate_probabilities(eligible, (s @ existing).softmax(-1), evidence)
        candidate = alternate if args.full_readout else [
            recover_uncertain(a, b) for a, b in zip(baseline, alternate, strict=True)
        ]
        predictions = {r["id"]: r for r in candidate}

    results = []
    for row in records:
        prediction = predictions.get(row["id"])
        if prediction is None:
            prediction = {"id": row["id"], "score": None,
                          "review_reason": "context_too_long" if row["messages"] else "insufficient_context"}
        results.append(prediction)
    write_json(out / "score-report.json", report(MODEL, checkpoint["revision"], research_digest, results))
    if args.case_details:
        write_json(out / "diagnostic.json", results)
        write_json(out / "comparison-inputs.json", {"current": baseline, "readout": alternate})


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("ordinal", "snapshot", "input", "readout", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--full-readout", action="store_true", help="Replace all severity estimates for research comparison")
    parser.add_argument("--case-details", action="store_true", help="Write diagnostic probabilities for research cases")
    run(parser.parse_args())
