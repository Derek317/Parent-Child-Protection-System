# Why d1 withholds scores in IG Guard

18 November 2026 · Local research

The current scorer withheld numbers for 24 of 48 complete exchanges in the
60-case benchmark. The evidence probability blocked 13, and the four-level
severity probabilities were too close together in the other 11. d1 computed
severity probabilities for every case. The Android debug preview imports
the resulting report from the scorer. [Current scoring logic](../../igguard-d1-experiment/experiments/d1-grooming/ordinal/score.py)

Removing only the evidence check would defer just 1 of 12 unresolved cases,
down from 7. Ignoring both checks would flag 4 of 24 low or potential cases
and 2 of 12 unresolved cases, up from 2 and 1 respectively. The recorded
evidence probabilities overlap for complete and incomplete conversations.

## Tested approaches

- I fitted a separate evidence classifier over d1's existing representations.
  It admitted more complete cases, but deferred just 1 of 12 unresolved
  cases on the 60-case replay and 0 of 18 on the older replay.
- I tested a separate severity classifier while retaining the current evidence
  check. It learned four ordered levels from the pinned d1 representations
  on 48 complete training examples. I chose the penalty and scaling using
  the 45-case development split. None of the tested classifiers met all the
  development safeguards.
- I tested a restricted fallback after examining the first two results. It
  takes effect only when the existing evidence check passes but severity is
  uncertain. If both classifiers estimate at least 50 and the second passes
  the confidence check, use the lower number. I scored the 18 fresh examples
  after fixing this rule. [Fallback and local scoring script](rescore.py)

## Results

| Measure on the 60-case replay | Current d1 | Restricted fallback | Separate severity classifier |
| --- | ---: | ---: | ---: |
| Complete cases scored | 24/48 | 26/48 | 34/48 |
| Exact level or review decision | 12/60 | 12/60 | 20/60 |
| Moderate or high cases scoring at least 50 | 3/24 | 5/24 | 6/24 |
| Low or potential cases scoring at least 50 | 2/24 | 2/24 | 4/24 |
| Unresolved cases scoring at least 50 | 1/12 | 1/12 | 1/12 |
| Correctly deferred unresolved cases | 7/12 | 7/12 | 7/12 |

The fallback recovered two scores. One was a Cantonese conversation
and one was mixed-language. Both were reference high cases and the fallback
scored both moderate. This improves threshold detection on that replay while
exact agreement stays at 12/60. In the older 90-case replay it recovered one
moderate case and introduced zero additional false alerts. [Per-case review](case-review.csv)

On the 18 fresh examples, the fallback recovered zero scores. Both it and the
current scorer gave numbers to 8 of 12 complete exchanges and detected 3 of
6 concerning examples. The full severity classifier scored 9 of 12 complete
exchanges and detected 5 of 6 concerning examples, but added an alert on a low
case and one on an unresolved case. The fresh evaluation covers two constructed
scenarios in English, Cantonese and mixed chat. Accuracy on live conversations
remains unverified. [Fresh cases](fresh-cases.jsonl) · [All counts by language](comparison.json)

## Try it in the debug preview

Open **對話風險評分（試驗）** in the parent overview and import the score file.
The reports contain score and review status with opaque IDs. The case-review
CSV matches those IDs to examples and reference labels. The Android report
parser accepted both exported files in a Robolectric test. [Restricted fallback demo](score-report.json) · [Full classifier demo](experimental-readout-report.json)

To score a new local JSONL file, use the same Python environment and pinned
checkpoint as the existing d1 harness. Each line takes the existing id and
messages format. The default is the restricted fallback. Pass
the full-readout flag for comparison.

    python rescore.py --ordinal /path/to/repo/experiments/d1-grooming/ordinal --snapshot /path/to/pinned-d1 --readout severity-readout.safetensors --input /path/to/conversations.jsonl --output /path/to/new-output-dir

Both variants are research candidates for manual review. The fallback addresses
uncertain severity only. The larger group rejected at the evidence check needs
training data that shows what a complete exchange looks like across multiple
contexts, including Cantonese.

[Severity classifier selection](selection.json) · [Original model license](LICENSE)
