import unittest

from rescore import recover_uncertain


class RecoveryTest(unittest.TestCase):
    def test_only_recovers_high_concern_with_sufficient_evidence(self):
        baseline = {"score": None, "raw_score": 51, "review_reason": "uncertain_score"}
        second = {"score": 84, "raw_score": 84, "review_reason": None}
        self.assertEqual(recover_uncertain(baseline, second)["score"], 51)
        self.assertEqual(recover_uncertain(baseline, second)["predicted"], 2)
        self.assertIs(recover_uncertain({**baseline, "review_reason": "insufficient_context"}, second)["score"], None)
        self.assertIsNone(recover_uncertain({**baseline, "raw_score": 49.9}, second)["score"])
        self.assertIs(recover_uncertain(baseline, {**second, "score": None}), baseline)
        self.assertIs(recover_uncertain(baseline, {**second, "score": 49.9}), baseline)
        already_scored = {"score": 31, "raw_score": 31, "review_reason": None}
        self.assertIs(recover_uncertain(already_scored, second), already_scored)
