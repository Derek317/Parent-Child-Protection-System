"""Fit independent evidence and ordinal heads over the pinned d1 scorer inputs."""
import argparse
import json
from pathlib import Path
import sys

import torch
from safetensors.torch import load_file, save_file


def fit_linear(inputs, targets, penalty):
    x = inputs.double()
    y = targets.double()
    x0, y0 = x.mean(0), y.mean(0)
    x, y = x - x0, y - y0
    gram = x @ x.T
    gram.diagonal().add_(penalty * gram.diagonal().mean().clamp_min(1e-12))
    weight = x.T @ torch.linalg.solve(gram, y)
    return weight.float(), (y0 - x0 @ weight).float()


def evaluate_probabilities(rows, p, context):
    from score import assess, band
    result = []
    for row, ps, c in zip(rows, p.tolist(), context.tolist(), strict=True):
        actual = assess({"answers": {
            "severity": {"type": "score", "probabilities": dict(zip("0123", ps)),
                         "score": sum(i * n for i, n in enumerate(ps))},
            "enough": {"type": "noul", "noul": c},
        }, "usage": {"output_tokens": 0}})
        result.append({**actual, "id": row["id"], "language": row["language"], "family": row["family"],
                       "expected": row["level"], "predicted": None if actual["score"] is None else band(actual["score"])})
    return result


def predict(split, heads):
    rows, s, e, _, _ = split
    context = torch.sigmoid((e[:, 1] - e[:, 0]) @ heads["evidence_weight"] + heads["evidence_bias"])
    if heads["severity_weight"].ndim == 1:
        severity = s @ heads["severity_weight"]
    else:
        severity = s.flatten(1) @ heads["severity_weight"] + heads["severity_bias"]
    return evaluate_probabilities(rows, severity.softmax(dim=-1), context)


def run(args):
    sys.path.insert(0, str(args.ordinal))
    from context_fit import LANGUAGES, digest, load_split, metrics, rank, verify_separation
    from weight_edit import TENSOR
    from run import write_json
    torch.set_num_threads(2)

    out = args.output
    out.mkdir(parents=True, exist_ok=False)
    fit = load_split(args.features, "fit")
    validation = load_split(args.features, "selection")
    verify_separation(fit[0], validation[0])
    current_path = args.ordinal / "context-results/d1-context-head.safetensors"
    frozen = json.loads((args.ordinal / "context-results/selection.json").read_text())
    if digest(current_path) != frozen["patch_sha256"]:
        raise ValueError("Current d1 weight file does not match its study")
    for name, split in (("fit", fit), ("selection", validation)):
        if split[4]["data_sha256"] != frozen[name + "_sha256"]:
            raise ValueError("Unexpected development inputs")
    current = load_file(current_path)[TENSOR][0]
    baseline = {"evidence_weight": current, "evidence_bias": torch.zeros(()),
                "severity_weight": current, "severity_bias": torch.zeros(4)}
    rows, s, e, _, _ = fit
    complete = [i for i, r in enumerate(rows) if r["level"] is not None]
    levels = torch.tensor([rows[i]["level"] for i in complete])
    sufficient = torch.tensor([2.5 if r["level"] is not None else -2.5 for r in rows])
    sev_target = -2.5 * (torch.arange(4)[None] - levels[:, None]).abs().float()
    sev_target -= sev_target.mean(dim=1, keepdim=True)
    penalties = (0.05, 0.3, 1.0, 5.0)
    recorded = []
    selected = {"current": baseline}
    for independent_severity in (False, True):
        choices = []
        for e_reg in penalties:
            ew, eb = fit_linear(e[:, 1] - e[:, 0], sufficient, e_reg)
            for s_reg in (penalties if independent_severity else (None,)):
                sw, sb = fit_linear(s[complete].flatten(1), sev_target, s_reg) if s_reg else (current, torch.zeros(4))
                for scale in ((1, 2, 3) if independent_severity else (1,)):
                    heads = {"evidence_weight": ew, "evidence_bias": eb, "severity_weight": sw * scale,
                             "severity_bias": sb * scale}
                    m = metrics(predict(validation, heads))
                    safety, exact, risk, false, high, coverage = rank(m)
                    config = {"evidence_penalty": e_reg, "severity_penalty": s_reg, "severity_scale": scale}
                    recorded.append({"config": config, "metrics": m})
                    choices.append(((safety, risk, exact, false, high, coverage), config, heads))
        _, config, heads = max(choices, key=lambda x: x[0])
        name = "separate" if independent_severity else "evidence_only"
        selected[name] = heads
        target = out / f"{name}.safetensors"
        save_file(heads, target, metadata={"base_sha256": frozen["base_sha256"], "rubric_sha256": frozen["rubric_sha256"]})
        print(name, config, "selection", metrics(predict(validation, heads)))
        write_json(out / f"{name}-frozen.json", {**config, "patch_sha256": digest(target),
                                                "fit_sha256": fit[4]["data_sha256"],
                                                "selection_sha256": validation[4]["data_sha256"]})
    write_json(out / "candidates.json", recorded)

    for split_name in ("selection", "test", "legacy"):
        split = load_split(args.features, split_name)
        if split_name == "test":
            for dev in (fit, validation):
                verify_separation(dev[0], split[0])
        out_split = out / split_name
        out_split.mkdir()
        comparison = {"input_sha256": split[4]["data_sha256"]}
        for variant, heads in selected.items():
            records = predict(split, heads)
            comparison[variant] = {key: metrics([r for r in records if key == "all" or r["language"] == key])
                                   for key in ("all", *LANGUAGES)}
            (out_split / f"{variant}.jsonl").write_text("".join(json.dumps(r, allow_nan=False) + "\n" for r in records))
            print(split_name, variant, comparison[variant]["all"], flush=True)
        write_json(out_split / "comparison.json", comparison)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for option in ("ordinal", "output", "features"):
        parser.add_argument("--" + option, type=Path, required=True)
    run(parser.parse_args())
