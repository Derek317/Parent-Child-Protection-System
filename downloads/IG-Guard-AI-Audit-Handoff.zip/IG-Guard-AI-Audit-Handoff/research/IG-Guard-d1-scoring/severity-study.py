"""Keep the existing evidence check while attempting to improve severity scoring."""
import argparse
import json
from pathlib import Path
import sys

import torch
from safetensors.torch import load_file, save_file

from spike import evaluate_probabilities, fit_linear


def predict(split, scorer, current):
    rows, s, e, _, _ = split
    logits = (s if scorer["weight"].ndim == 1 else s.flatten(1)) @ scorer["weight"] + scorer["bias"]
    sufficient = (e @ current).softmax(-1)[:, 1]
    return evaluate_probabilities(rows, logits.softmax(-1), sufficient)


def run(args):
    sys.path.insert(0, str(args.ordinal))
    from context_fit import LANGUAGES, digest, load_split, metrics, verify_separation
    from weight_edit import TENSOR
    from run import write_json

    torch.set_num_threads(2)
    args.output.mkdir(parents=True, exist_ok=False)
    train = load_split(args.features, "fit")
    selection = load_split(args.features, "selection")
    verify_separation(train[0], selection[0])
    path = args.ordinal / "context-results/d1-context-head.safetensors"
    model = json.loads((args.ordinal / "context-results/selection.json").read_text())
    if digest(path) != model["patch_sha256"]:
        raise ValueError("Pinned current d1 edit mismatch")
    current = load_file(path)[TENSOR][0]
    complete = [i for i, row in enumerate(train[0]) if row["level"] is not None]
    y = torch.tensor([train[0][i]["level"] for i in complete])
    targets = -2.5 * (torch.arange(4)[None] - y[:, None]).abs().float()
    targets -= targets.mean(dim=1, keepdim=True)
    base = {"weight": current, "bias": torch.zeros(4)}
    baseline = metrics(predict(selection, base, current))

    def evaluate(name, scale, penalty, readout):
        m = metrics(predict(selection, readout, current))
        # Keep development protections at the current model's measured levels.
        flags = m["benign_alerts"] + m["potential_alerts"]
        viable = (flags <= baseline["benign_alerts"] + baseline["potential_alerts"]
                  and m["partial_alerts"] <= baseline["partial_alerts"]
                  and m["partial_deferred"] >= baseline["partial_deferred"]
                  and m["risk_alerts"] >= baseline["risk_alerts"]
                  and m["exact"] >= baseline["exact"])
        return ((viable, m["complete_scored"], m["risk_alerts"], m["exact"], m["high_exact"]),
                {"method": name, "scale": scale, "ridge": penalty, "selection": m}, readout)

    calibrations = [evaluate("scale", scale, None, {"weight": current * scale, "bias": base["bias"]})
                    for scale in (1, 1.2, 1.5, 2, 3)]
    readouts = []
    for penalty in (0.05, 0.3, 1, 5):
        w, b = fit_linear(train[1][complete].flatten(1), targets, penalty)
        for scale in (1, 2, 3):
            readouts.append(evaluate("readout", scale, penalty, {"weight": w*scale, "bias": b*scale}))
    winners = {"current": base}
    for name, group in (("scale", calibrations), ("readout", readouts)):
        rank, chosen, weights = max(group, key=lambda c: c[0])
        winners[name] = weights
        dest = args.output/f"{name}.safetensors"
        save_file(weights, dest, metadata={"base_sha256": model["base_sha256"],
                                          "current_edit_sha256": model["patch_sha256"],
                                          "rubric_sha256": model["rubric_sha256"]})
        write_json(args.output/f"{name}-frozen.json",
                   {**chosen, "passed_development": rank[0], "tensor_sha256": digest(dest),
                    "candidates": [{"feasible": k[0], **d} for k, d, _ in group]})
        print(name, rank, chosen)
    for name in ("test", "legacy"):
        split = load_split(args.features, name)
        if name == "test":
            verify_separation(train[0], split[0])
            verify_separation(selection[0], split[0])
        directory = args.output / name
        directory.mkdir()
        comparisons = {}
        for variant, weights in winners.items():
            rows = predict(split, weights, current)
            comparisons[variant] = {key: metrics([row for row in rows if key == "all" or row["language"] == key])
                                    for key in ("all", *LANGUAGES)}
            (directory/f"{variant}.jsonl").write_text("".join(json.dumps(r, allow_nan=False)+"\n" for r in rows))
            print(name, variant, comparisons[variant]["all"])
        write_json(directory/"comparison.json", comparisons)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for option in ("ordinal", "output", "features"):
        parser.add_argument("--"+option, type=Path, required=True)
    run(parser.parse_args())
