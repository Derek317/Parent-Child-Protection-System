# Laya Multilingual comparison protocol

18 November 2026. The benchmark compares Laya Multilingual as published with the
three frozen d1 configurations already evaluated in IG Guard. It uses the 45-case
development selection split, the 60-case held-out split and the older 90-case
replay. Only the conversation's speaker names and text enter the model. All
examples are constructed from published case reports or safeguarding guidance.

Use the pinned original model revision
`92d22143468d8af669dc1a5a0480a2b21b4fe56e` and Laya runtime `0.4.35`.
Run locally with the checkpoint's shipped temperatures. Evaluate two ways to
pose the original rubric: its original `score` and `noul` questions, and the
same instructions and criteria as four-option and two-option `choice` questions
with neutral letter keys. The model card documents problems with the original
question types. Both versions map the severity distribution to the expectation
on 0–100. They use the original 0.5 evidence threshold, 0.4 maximum probability
threshold and the original bands at 25, 50 and 75. Since these are common
decision rules, the Laya-specific action head is outside the comparison.

Select the question format on the 45 development cases using the same
`context_fit.rank` rule as the recent d1 edit, with ties going to the original
question format. Freeze that selection before held-out inference. Evaluate the
other format as a diagnostic. The 60-case split is the primary result and the
90-case replay checks generalization to shorter and more varied inputs.

For the APK, require strictly higher exact five-way agreement and strictly fewer
alerts at 50 or higher on low plus potential cases than the current context-aware
d1 edit on the 60-case set. Require at least as many detected moderate and high
cases at that threshold. A low alert or alert on unresolved evidence is tracked
separately and must not increase. Check the older replay for any loss in risk
detection or increase in low or potential alerts. Report risk results for each
language. Scores in this study express rubric concern levels and remain
uncalibrated. An export is a research result for reviewing the comparison.

## Additional diagnostic

After both formats deferred all 45 development examples, we defined one
additional question before reading any held-out metrics. It combines the same
four rubric choices with an explicit fifth choice for insufficient evidence.
A fifth-choice probability above 0.5 sends the conversation to review.
For the remaining cases, normalize the four severity probabilities and apply
the same 0.4 confidence threshold and the original score bands. This is a
separate question design and is reported separately from the frozen comparison.
It uses the published checkpoint with no calibration or changes to weights.
