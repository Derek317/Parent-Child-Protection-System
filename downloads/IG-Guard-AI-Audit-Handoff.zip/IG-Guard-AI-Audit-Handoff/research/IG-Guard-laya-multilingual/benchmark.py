"""Evaluate the original Laya checkpoint against the frozen IG Guard d1 baselines."""
import argparse
from hashlib import sha256
from importlib.metadata import version
import json
from pathlib import Path
import sys
import time

MODEL = "convaiinnovations/laya-multilingual"
REVISION = "92d22143468d8af669dc1a5a0480a2b21b4fe56e"
EXPECTED_FILES = {
    "model.safetensors": "9d628fd971b700382ac6f65920a86f149777b2e748e0c955fb3b19695aa8f204",
    "tokenizer/tokenizer.json": "609d8f4c067cd3950f88594c5a802616cea245823836ef5848ee4fc40aab5b6f",
}
FORMATS = ("score_noul", "choice")


def questions_from(rubric):
    severity = rubric["questions"]["severity"]
    enough = rubric["questions"]["enough"]
    return rubric["questions"] | {
        "severity_choice": {**severity, "type": "choice",
                            "criteria": dict(zip("abcd", severity["criteria"], strict=True))},
        "enough_choice": {**enough, "type": "choice",
                          "criteria": {"a": enough["criteria"]["false"], "b": enough["criteria"]["true"]}},
    }


def decode(answers, form, assess):
    if form == "score_noul":
        severity, enough = answers["severity"], answers["enough"]["noul"]
        keys = "0123"
    elif form == "choice":
        severity, enough = answers["severity_choice"], answers["enough_choice"]["probabilities"]["b"]
        keys = "abcd"
    else:
        probs = answers["joint"]["probabilities"]
        if set(probs) != set("abcde") or abs(sum(probs.values()) - 1) > 0.00026:
            raise ValueError("Unexpected Laya joint distribution")
        enough = sum(probs[k] for k in "abcd") / sum(probs.values())
        severity = {"probabilities": {k: (probs[k] / sum(probs[a] for a in "abcd") if enough else 0.25) for k in "abcd"}}
        keys = "abcd"
    probs = severity["probabilities"]
    if set(probs) != set(keys) or abs(sum(probs.values()) - 1) > 0.00021:
        raise ValueError("Unexpected Laya severity distribution")
    # The SDK rounds each probability to four decimals. Normalize the rounding residual.
    p = [probs[k] / sum(probs.values()) for k in keys]
    return assess({"answers": {
        "severity": {"type": "score", "probabilities": {str(i): v for i, v in enumerate(p)},
                     "score": sum(i * v for i, v in enumerate(p))},
        "enough": {"type": "noul", "noul": enough},
    }, "usage": {"output_tokens": 0}})


def run(args):
    start = time.perf_counter()
    root = args.repo / "experiments/d1-grooming"
    sys.path.insert(0, str(root / "ordinal"))
    from context_fit import LANGUAGES, metrics, rank
    from score import assess, band, context_fits, read_cases, RUBRIC
    from laya import load
    from laya.common import encode_text, serialize_state, state_room
    import torch

    out = args.output
    out.mkdir(parents=True, exist_ok=False)
    old = root / "ordinal/context-results"
    inputs = {
        "selection": root / "ordinal/context-data/selection.jsonl",
        "test": root / "ordinal/context-data/test.jsonl",
        "legacy": root / "grounded/data/blind.jsonl",
    }
    selection = json.loads((old / "selection.json").read_text())
    digest = sha256((root / "ordinal/rubric.json").read_bytes()).hexdigest()
    if digest != selection["rubric_sha256"]:
        raise ValueError("Rubric differs from the frozen d1 benchmark")

    def write(name, data):
        (out / name).write_text(json.dumps(data, indent=2, ensure_ascii=False, allow_nan=False) + "\n")

    torch.set_num_threads(4)
    agent = load(str(args.snapshot.resolve()), device="cpu", expected_sha256=EXPECTED_FILES)
    questions = questions_from(RUBRIC)
    formats = FORMATS
    if args.joint:
        rubric = questions["severity_choice"]
        questions = {"joint": {
            **rubric,
            "instructions": rubric["instructions"] + " Choose e if the exchange lacks evidence for a specific level.",
            "criteria": {**rubric["criteria"], "e": RUBRIC["questions"]["enough"]["criteria"]["false"]},
        }}
        formats = ("joint",)
    # The SDK uses this budget to truncate serialized states. Refuse any affected example.
    budget = min(state_room(agent.tok, agent._to_internal(q), agent.cfg["max_len"], agent.cfg["head_max_len"])
                 for q in questions.values())
    write("run.json", {
        "model": MODEL, "revision": REVISION, "files_sha256": EXPECTED_FILES,
        "runtime": {n: version(n) for n in ("laya", "torch", "transformers", "safetensors", "tokenizers")},
        "device": "cpu", "rubric_sha256": digest, "min_state_token_budget": budget, "questions": questions,
        "selection_rule": "context_fit.rank; identical rank preserves score+noul",
    })
    for split, path in inputs.items():
        rows, data_hash = read_cases(path)
        comparators = None if split == "selection" else json.loads((old / split / "comparison.json").read_text())
        expected_hash = selection["selection_sha256"] if comparators is None else comparators["data_sha256"]
        if data_hash != expected_hash:
            raise ValueError(f"{split} differs from the frozen d1 benchmark")
        if split == "legacy":
            for row in rows:
                row["level"] = 0 if row["label"] == "benign" else RUBRIC["replay_expected_risk_band_by_family"].get(row["family"])
        states = [{"chat": r["messages"]} for r in rows]
        lengths = [len(encode_text(agent.tok, serialize_state(s), add_special_tokens=False)["input_ids"]) for s in states]
        if max(lengths) > budget or not all(r["messages"] and context_fits(r["messages"]) for r in rows):
            raise ValueError(f"{split} would truncate conversation text")
        by_form = {form: [] for form in formats}
        for offset in range(0, len(states), 5):
            replies = agent.predict_batch(states[offset:offset + 5], questions, batch_size=5)
            for row, response in zip(rows[offset:offset + 5], replies, strict=True):
                if response["usage"]["output_tokens"] != 0:
                    raise ValueError("Expected a non-generative decision")
                for form, records in by_form.items():
                    result = decode(response["answers"], form, assess)
                    pred = None if result["score"] is None else band(result["score"])
                    records.append({**result, "id": row["id"], "language": row["language"], "family": row["family"],
                                    "expected": row["level"], "predicted": pred})
            if offset % 20 == 0 or offset + 5 >= len(states):
                print(f"{split}: {min(offset + 5, len(states))}/{len(states)}", flush=True)
        stats = {form: {key: metrics([r for r in records if key == "all" or r["language"] == key])
                        for key in ("all", *LANGUAGES)} for form, records in by_form.items()}
        if split == "selection":
            chosen = max(formats, key=lambda name: rank(stats[name]["all"]))
            write("frozen-selection.json", {"format": chosen, "data_sha256": data_hash,
                                           "metrics": stats, "ranks": {name: rank(stats[name]["all"]) for name in formats}})
            print(f"Frozen format: {chosen}", flush=True)

        for form, records in by_form.items():
            (out / f"{split}-{form}.jsonl").write_text("".join(json.dumps(r, allow_nan=False) + "\n" for r in records))
        write(f"{split}-comparison.json", {
            "data_sha256": data_hash, "n": len(rows), "longest_state_tokens": max(lengths), "selected": chosen,
            "laya": stats, "d1": comparators,
        })
    write("timing.json", {"cpu_seconds_wall": time.perf_counter() - start})


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("repo", "output", "snapshot"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--joint", action="store_true", help="Run the separate five-choice diagnostic")
    run(parser.parse_args())
