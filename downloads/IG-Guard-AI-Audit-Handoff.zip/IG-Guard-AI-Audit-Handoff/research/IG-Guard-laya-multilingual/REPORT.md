# IG Guard model comparison

18 November 2026

Laya's selected question format tied the current d1 edit at 12/60
exact matches by deferring all 60 cases. It detected 0/24
moderate or high cases, compared with 3/24 for the current d1 edit.
The separate five-choice diagnostic had 11/60 exact matches, detected
1/24 moderate or high cases and produced
1/24 alerts on low or potential cases.

On the held-out cases, the five-choice version reduced out-of-band alerts,
and both exact agreement and risk detection fell. The benchmark therefore
failed the APK replacement criteria.

## Held-out cases

| Measure | Original d1 | Previous d1 edit | Current d1 edit | Laya score + yes/no | Laya separate choices | Laya five choices |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Exact match, including review | 11/60 | 7/60 | 12/60 | 12/60 | 12/60 | 11/60 |
| Complete conversations scored | 3/48 | 23/48 | 24/48 | 0/48 | 0/48 | 23/48 |
| Low cases scoring at least 50 | 0/12 | 1/12 | 0/12 | 0/12 | 0/12 | 0/12 |
| Potential cases scoring at least 50 | 0/12 | 0/12 | 2/12 | 0/12 | 0/12 | 1/12 |
| Unresolved cases scoring at least 50 | 0/12 | 0/12 | 1/12 | 0/12 | 0/12 | 0/12 |
| Unresolved cases sent to review | 11/12 | 3/12 | 7/12 | 12/12 | 12/12 | 6/12 |
| Moderate or high cases scoring at least 50 | 1/24 | 4/24 | 3/24 | 0/24 | 0/24 | 1/24 |
| High cases scored high | 0/12 | 0/12 | 0/12 | 0/12 | 0/12 | 0/12 |

The two Laya variants with a separate context question sent all 60 examples to
review and returned zero safety alerts. The benchmark counts an exact match
for an unresolved example sent to review. This explains the two 12/60 results.
The appendix includes the outputs and reference for each individual case.
[Per-case review](case-review.csv) · [Full metrics by language](results/test-comparison.json) · [Five-choice metrics by language](joint/test-comparison.json)

### Hong Kong Cantonese

| Measure | Current d1 edit | Laya score + yes/no | Laya separate choices | Laya five choices |
| --- | ---: | ---: | ---: | ---: |
| Exact match, including review | 4/20 | 4/20 | 4/20 | 4/20 |
| Complete conversations scored | 4/16 | 0/16 | 0/16 | 7/16 |
| Low cases scoring at least 50 | 0/4 | 0/4 | 0/4 | 0/4 |
| Potential cases scoring at least 50 | 1/4 | 0/4 | 0/4 | 0/4 |
| Unresolved cases scoring at least 50 | 0/4 | 0/4 | 0/4 | 0/4 |
| Unresolved cases sent to review | 4/4 | 4/4 | 4/4 | 2/4 |
| Moderate or high cases scoring at least 50 | 0/8 | 0/8 | 0/8 | 0/8 |
| High cases scored high | 0/4 | 0/4 | 0/4 | 0/4 |

## Older replay

| Measure | Original d1 | Previous d1 edit | Current d1 edit | Laya score + yes/no | Laya separate choices | Laya five choices |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Exact match, including review | 15/90 | 13/90 | 8/90 | 18/90 | 25/90 | 23/90 |
| Complete conversations scored | 5/72 | 45/72 | 44/72 | 2/72 | 25/72 | 70/72 |
| Low cases scoring at least 50 | 1/36 | 1/36 | 1/36 | 1/36 | 0/36 | 0/36 |
| Potential cases scoring at least 50 | 0/6 | 0/6 | 0/6 | 0/6 | 0/6 | 0/6 |
| Unresolved cases scoring at least 50 | 0/18 | 0/18 | 0/18 | 0/18 | 0/18 | 0/18 |
| Unresolved cases sent to review | 14/18 | 2/18 | 7/18 | 18/18 | 17/18 | 0/18 |
| Moderate or high cases scoring at least 50 | 0/30 | 3/30 | 1/30 | 0/30 | 0/30 | 1/30 |
| High cases scored high | 0/9 | 0/9 | 0/9 | 0/9 | 0/9 | 0/9 |

[Replay metrics](results/legacy-comparison.json) · [Five-choice replay metrics](joint/legacy-comparison.json)

## Procedure

Both separate-question variants deferred all 45 development conversations. The
declared tie-break kept the native severity score and yes/no evidence question.
After seeing those development results and before reading held-out results, we
defined the five-choice diagnostic to check whether a stand-alone evidence
question was responsible. On the development set, the five-choice version scored 27 of 36 complete
conversations and detected 2 of 18 moderate or high cases. The model weights
and shipped temperatures were identical for all three formats. The inference ran on a local CPU with Laya
0.4.35. The tokenizer audit confirmed that all messages and rubric options fit.
[Protocol](protocol.md) · [Development results and selection](results/frozen-selection.json) · [Input length audit](results/input-length-audit.json) · [Model and runtime provenance](results/run.json) · [Benchmark script](benchmark.py)

The benchmark uses constructed examples based on published sources with related
English, Cantonese and mixed-language versions. The primary comparison covers four
distinct scenarios, so the 60 results should be interpreted as a challenge set.
Each case describes a teen discussing events with someone they know. Live incoming
messages and accuracy on actual family conversations remain untested.
[Laya model card](https://huggingface.co/convaiinnovations/laya-multilingual/tree/92d22143468d8af669dc1a5a0480a2b21b4fe56e)
