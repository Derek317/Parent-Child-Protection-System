# Reproduction notes

## Verify results without downloading models

From the extracted folder, run `python verify_audit.py` with Python 3.11 or
later. It uses the saved predictions, reference labels and documented cutoffs.
A check of the model's actual predictions requires rerunning the model.

For cached d1 fitting, use the Python 3.12 environment in the
[pinned experimental setup](experiments/d1-grooming/README.md). Run from this
folder and choose new directories for outputs. Set PYTHONDONTWRITEBYTECODE=1
for runs from the extracted folder to preserve the hashed evidence snapshot.

```bash
python experiments/d1-grooming/ordinal/context_fit.py \
  --features cached-activations --output /tmp/audit-d1-context
python experiments/d1-grooming/ordinal/context_fit.py \
  --features cached-activations --output /tmp/audit-d1-context --split test
python experiments/d1-grooming/ordinal/context_fit.py \
  --features cached-activations --output /tmp/audit-d1-context --split legacy
python research/IG-Guard-d1-scoring/severity-study.py \
  --ordinal experiments/d1-grooming/ordinal --features cached-activations \
  --output /tmp/audit-d1-severity
```

The caches contain per-option activations from the original F32 model, equaling
its native readout when multiplied by the original weights. A refit from the
extracted ZIP reproduced the selected coefficients exactly. The generated
safetensors file hash can differ when metadata is serialized in another key
order. Compare the tensor payload and parsed metadata for refit parity. For an audit of the
caches themselves, rerun [activation extraction](experiments/d1-grooming/ordinal/context-data/README.md)
against the verified F32 checkpoint. Official source checksums and the model
revision are in the [snapshot manifest](experiments/d1-grooming/evidence/model-provenance.json).
The local weight loader uses reviewed, pinned Python from the model snapshot.
Review that source and run model code in an isolated environment.

## Rerun the compressed replay

See the [artifact manifest](research/IG-Guard-quantized-replay/artifacts.json) for
the three files to download with their exact SHA-256 digests. The runtime was
llama.cpp b12503, commit 4577932fa, Linux x86_64. Verify hashes before executing
external code or loading weights. Start the following two localhost servers in
separate terminals. Supply the path to the extracted runtime libraries through
LD_LIBRARY_PATH if required by your installation.

```bash
llama-server -m /path/to/d1-omni-600M-Q8_0.gguf --host 127.0.0.1 --port 19087 \
  -c 8192 -b 2048 -ub 2048 --threads 4 --parallel 4 -ngl 0
llama-server -m /path/to/Qwen3-Embedding-0.6B.Q4_K_M.gguf --embedding --pooling last \
  --host 127.0.0.1 --port 19086 -c 2048 -b 2048 -ub 2048 --threads 2 --parallel 1 -ngl 0
```

Run the clients from the extracted folder with the pinned Python environment.

```bash
python research/IG-Guard-quantized-replay/gguf_replay.py \
  --backend d1 --port 19087 --root experiments/d1-grooming --output /tmp/audit-d1-gguf
python research/IG-Guard-quantized-replay/gguf_replay.py \
  --backend qwen --port 19086 --root experiments/d1-grooming --output /tmp/audit-qwen-gguf
```

The d1 client saves an ordered checkpoint after each case. Keep the same
model, rubric and inference settings if resuming. The Qwen client fits and
freezes its readout on development data before the replay.

## Rerun Laya

The model was `convaiinnovations/laya-multilingual` at revision
`92d22143468d8af669dc1a5a0480a2b21b4fe56e`, with Laya Python runtime 0.4.35.
Download the pinned safetensors, encoder and tokenizer configs locally. The
[run manifest](research/IG-Guard-laya-multilingual/results/run.json) specifies
file hashes, package versions and exact question definitions. The PyPI wheel
used in the run was `laya-0.4.35-py3-none-any.whl`, SHA-256
`2bb201032a83aee0aee07fa0dd76904753de1f35fec26c7e78640229dd5eb791`.

```bash
HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 USE_TF=0 \
  python research/IG-Guard-laya-multilingual/benchmark.py \
  --repo "$PWD" --snapshot /path/to/laya-snapshot --output /tmp/audit-laya
HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 USE_TF=0 \
  python research/IG-Guard-laya-multilingual/benchmark.py \
  --repo "$PWD" --snapshot /path/to/laya-snapshot --output /tmp/audit-laya-joint --joint
```

## Upstream references

- ChatLab source snapshot at `bb292e35a00d68132de203e8b2d52e2d7e74dcd3`. [Platform architecture](https://github.com/ChatLab/ChatLab/blob/bb292e35a00d68132de203e8b2d52e2d7e74dcd3/docs/en/contributing/development.md#platform-terminology) · [Embedding profiles](https://github.com/ChatLab/ChatLab/blob/bb292e35a00d68132de203e8b2d52e2d7e74dcd3/packages/node-runtime/src/semantic-index/embedding/profiles.ts)
- The IG Guard native inference notes describe a possible Android route. The evidence in this handoff comes from desktop inference and an Android report-parser test in Robolectric. [Android feasibility notes](experiments/d1-grooming/ANDROID.md)
