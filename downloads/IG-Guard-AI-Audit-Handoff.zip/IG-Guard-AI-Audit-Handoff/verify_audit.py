"""Recompute selected published figures using only Python's standard library."""
from collections import Counter
from hashlib import file_digest
import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent
EXPERIMENT = HERE / "experiments/d1-grooming"
RESEARCH = HERE / "research"
LANGUAGES = ("all", "en", "zh-Hant-yue", "mixed")


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def json_file(path):
    return json.loads(path.read_text())


def records(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line]


def align(predictions, cases):
    require(len(predictions) == len(cases), "Prediction count mismatch")
    require(len({row["id"] for row in cases}) == len(cases), "Duplicate fixture ID")
    for predicted, case in zip(predictions, cases, strict=True):
        require((predicted["id"], predicted["language"]) == (case["id"], case["language"]),
                "Prediction order or language mismatch")
        if "label" in predicted:
            require(predicted["label"] == case["label"], "Binary reference label mismatch")


def binary(predictions, cases, field, result):
    align(predictions, cases)
    cutoff = result["cutoff"]
    passing = {}
    for language in LANGUAGES:
        counts = Counter()
        for p, r in zip(predictions, cases, strict=True):
            if language != "all" and r["language"] != language:
                continue
            s = p[field]
            require(isinstance(s, (int, float)) and math.isfinite(s) and 0 <= s <= 1, "Invalid binary score")
            label, flagged = r["label"], s >= cutoff
            counts[label, flagged] += 1
            counts["review_band"] += r["label"] == "review" and .35 <= s <= .65
        tp, fn = counts["risk", True], counts["risk", False]
        fp, tn = counts["benign", True], counts["benign", False]
        expected = result["binary"][language]
        require((tp, fp, fn, tn, counts["review_band"]) ==
                tuple(expected[k] for k in ("tp", "fp", "fn", "tn", "gold_review_in_band")),
                f"Binary count mismatch for {field}/{language}")
        passing[language] = tp / (tp + fn) >= (.8 if language == "all" else .7) and fp / (fp + tn) <= (.2 if language == "all" else .3)
    require(result["gate"]["groups"] == passing and result["gate"]["pass"] == all(passing.values()),
            "Binary gate mismatch")


def ordinal(predictions, cases, stats):
    align(predictions, cases)
    levels = (0, 1, 2, 3, None)
    for language in LANGUAGES:
        matrix = [[0] * 5 for _ in levels]
        reasons = Counter()
        for prediction, case in zip(predictions, cases, strict=True):
            if language != "all" and case["language"] != language:
                continue
            expected, score = case["level"], prediction["score"]
            require(score is None or math.isfinite(score) and 0 <= score <= 100, "Invalid ordinal score")
            actual = None if score is None else sum(score >= t for t in (25, 50, 75))
            require((expected, actual) == (prediction["expected"], prediction["predicted"]), "Ordinal label mismatch")
            matrix[levels.index(expected)][levels.index(actual)] += 1
            if prediction["review_reason"]:
                reasons[prediction["review_reason"]] += 1
        require(matrix == stats[language]["confusion"] and dict(reasons) == stats[language]["review_reasons"],
                f"Ordinal confusion or review counts differ for {language}")


def main():
    manifest = json_file(HERE / "SHA256.json")
    require(len(manifest) == len([p for p in HERE.rglob("*") if p.is_file() and p.name != "SHA256.json"]),
            "Bundle file count differs from manifest")
    for path, expected in manifest.items():
        require(digest(HERE / path) == expected, f"File differs from manifest: {path}")
    print(f"Verified SHA-256 for {len(manifest)} files.")

    path = EXPERIMENT / "grounded/data/blind.jsonl"
    cases = records(path)
    quant = RESEARCH / "IG-Guard-quantized-replay"
    for name, variants in {
        "d1": {k: k for k in ("binary_original", "binary_context")},
        "qwen": {"fixed": "score", "tuned": "score"},
    }.items():
        model = quant / name
        metrics = json_file(model / "metrics.json")
        require(metrics["input_sha256"] == digest(path) and len(cases) == 90, "Unexpected 90-case fixture")
        for variant, field in variants.items():
            binary(records(model / "predictions.jsonl"), cases, field, metrics[variant])
            print(f"{name}/{variant}: 90 cases, confusion counts and quality gate verified.")
    rubric = json_file(EXPERIMENT / "ordinal/rubric.json")
    for case in cases:
        case["level"] = (0 if case["label"] == "benign" else
                         rubric["replay_expected_risk_band_by_family"].get(case["family"]))
    ordinal(records(quant / "d1/predictions.jsonl"), cases, json_file(quant / "d1/metrics.json")["ordinal"])
    print("Compressed d1 ordinal confusion matrices verified against the 90-case fixture.")
    frozen = json_file(quant / "qwen/frozen.json")
    require(frozen["classifier_sha256"] == digest(quant / "qwen/classifier.safetensors"), "Qwen readout differs")

    path = EXPERIMENT / "ordinal/context-data/test.jsonl"
    cases = records(path)
    prior = EXPERIMENT / "ordinal/context-results/test"
    control = json_file(prior / "comparison.json")
    require(control["data_sha256"] == digest(path) and len(cases) == 60, "Unexpected 60-case fixture")
    for name in ("original", "previous", "edited"):
        ordinal(records(prior / f"{name}.jsonl"), cases, control[name])
    print("All three d1 F32 ordinal variants verified against the 60-case fixture.")

    laya = RESEARCH / "IG-Guard-laya-multilingual"
    for directory, options in (("results", ("score_noul", "choice")), ("joint", ("joint",))):
        run = laya / directory
        metrics = json_file(run / "test-comparison.json")
        require(metrics["data_sha256"] == digest(path), "Laya fixture differs")
        for name in options:
            ordinal(records(run / f"test-{name}.jsonl"), cases, metrics["laya"][name])
    print("All three Laya ordinal variants verified against the 60-case fixture.")

    scoring = RESEARCH / "IG-Guard-d1-scoring"
    cases = records(scoring / "fresh-cases.jsonl")
    require(len(cases) == 18, "Unexpected fresh fixture")
    metrics = json_file(scoring / "comparison.json")["fresh"]
    for name, prediction in json_file(scoring / "fresh-diagnostic.json").items():
        ordinal(prediction, cases, metrics[name])
    print("Fresh d1 comparisons verified against the 18-case fixture.")


if __name__ == "__main__":
    main()
