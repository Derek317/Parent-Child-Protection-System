# IG Guard AI research handoff

18 November 2026 · Hong Kong

Give this folder to the auditor and ask them to start with this file. It covers the
conversation-scoring experiments, the Android preview, the ChatLab investigation,
and the latest compressed-model replay. The source snapshot is from local branch
`experiment/d1-grooming-2026-11-17` at
`6d79845b6d7888ece2d5cb1a7f8df69ee8556501`. The Laya, scoring follow-up
and compressed studies are separate research outputs.

## Executive summary

Neither compressed model passed the original risk detection gate on all 90 cases.
Neither d1 nor Laya reliably scored complete exchanges while deferring incomplete
ones. The Android debug preview imports score-only JSON generated offline.
Automatic on-device inference and alerts were outside these verified results.

| Experiment | Best-supported conclusion |
| --- | --- |
| 90-case d1 binary replay | Unmodified F32 caught 32/36 risk cases and falsely flagged 29/36 benign ones. A context-focused weight edit caught 17/36 and falsely flagged 13/36, missing the gate. |
| d1 ordinal weight study on 60 cases | The latest edit scored 24/48 complete cases and caught 3/24 moderate or high cases. It gave exact bands or correct review decisions on 12/60 and caught 0/8 moderate or high Cantonese cases. It also scored fewer cases correctly on the older replay than the previous edit. |
| Laya Multilingual, published weights | Both separate-question formats marked all 60 cases as insufficient. Five choices, including review, scored 23/48 complete cases, gave 11/60 exact matches, caught 1/24 moderate or high cases, and flagged 1/24 low or potential cases. |
| d1 scoring diagnosis | Of the 24 complete cases withheld by the current d1 edit, 13 failed the evidence check and 11 failed the confidence check. A restricted two-readout fallback recovered two scores and raised risk detection from 3/24 to 5/24 with unchanged false-alert counts. It recovered zero scores on the 18 fresh cases. The full alternate readout scored 34/48 complete cases and caught 6/24, with low/potential flags rising from 2/24 to 4/24. |
| Compressed d1 Q8, 407 MB | The original binary question caught 32/36 and falsely flagged 30/36. The context question caught 1/36 and falsely flagged 0/36. The ordinal scorer awarded numbers to 2/72 complete cases, down from 5/72 for unmodified F32. |
| Compressed Qwen3 Embedding Q4, 396 MB | Qwen returned embeddings. A separately fitted linear classifier caught 1/36 and falsely flagged 0/36 at the threshold chosen on development data. At a fixed 0.5 threshold it caught 24/36 and falsely flagged 20/36. |
| ChatLab review | ChatLab imports and searches chat histories. Its generative analysis calls a separately configured model. Its optional Qwen embedding weights support retrieval. The browser build supports browser-side import, storage and queries. The mobile idea for IG Guard was to assemble chronological context locally before scoring. |

## Read and verify the evidence

Run `python verify_audit.py` from this directory with Python 3.11 or later.
It verifies the file manifest and independently recomputes the compressed binary
gate, the d1/Laya 60-case confusion matrices, and the 18-case follow-up results.
It does not perform model inference.

| Path | Contents |
| --- | --- |
| [Grounded benchmark](experiments/d1-grooming/grounded/REPORT.md) | Sources, holdout design, original d1 scores and weight edits. Fixture files live under `grounded/data`. |
| [d1 context study](experiments/d1-grooming/ordinal/context-results/REPORT.md) | Context pairing, 48 candidate edits, frozen selection and original versus edited predictions. |
| [Laya comparison](research/IG-Guard-laya-multilingual/REPORT.md) | Baseline formats, separate five-choice diagnostic, full per-case scores and local benchmark script. |
| [d1 scoring follow-up](research/IG-Guard-d1-scoring/REPORT.md) | Abstention diagnosis, native sample parity, optional local readout and two importable reports. |
| [Compressed replay](research/IG-Guard-quantized-replay/REPORT.md) | Binary and ordinal results by language, model/runtime hashes, aligned 90-case review CSV and runner. |
| [Android report reader](RiskScoreReport.kt) | Strict parser and risk thresholds. Included Android tests show the intended import behavior. This source excerpt supports review of the reader. Build and run Android tests from the full checkout. |
| [Reproduction notes](REPRODUCE.md) | Cached and native inference routes, tool versions and full-model sources. |
| `cached-activations/` | Four frozen synthetic-case feature files for reproducing the d1 fitting and scoring work without downloading a large checkpoint. |

There are two different 90-case fixtures in the history. The latest result uses
`grounded/data/blind.jsonl`, with 36 risk, 36 benign and 18 unresolved cases.
The older feasibility fixture is `synthetic.jsonl`. Verify input hashes before
comparing figures. The grounded binary gate is at least 80% risk recall and at
most 20% benign false alerts overall, with at least 70% recall and at most 30%
false alerts within each language. Partial windows are counted separately. The
ordinal gate uses evidence at least 0.5, maximum severity probability at least
0.4 and score bands at 25, 50 and 75.

## What to ask the auditor to challenge

1. Recompute the confusion matrices from per-case predictions. Check the
   denominators, especially review cases and Cantonese recall. Compare the
   same binary questions and model versions across full precision and GGUF.
2. Check that fitting and cutoff choice used only development cases. The 60-case
   context test has four scenario groups and correlated translations. Its
   adaptations share an author with the selection set and reuse source families
   from the older replay. The fallback was proposed after reviewing earlier
   results, so its gains on those cases are retrospective.
3. Inspect false positives and missed serious cases. Determine whether weaker
   context or a soft distribution caused each abstention. Check whether the
   severity expectation genuinely distinguishes high cases instead of collapsing
   several levels into one score.
4. Review the 18 fresh follow-up examples separately. They cover two synthetic
   scenarios, so they give a narrow generalization check. No independent labels
   for live Instagram messages were collected. Claims about alert usefulness,
   real-world error rates, and Android performance need additional evidence.
5. For compressed comparisons, isolate runtime and prompt serialization from
   quantization effects. The GGUF replay used the released unmodified model,
   a different runtime from F32 and a local CPU. The first d1 attempt was
   interrupted before writing results. The reported retry started from the
   beginning and checkpointed all 90 cases.

The bundle contains synthetic/public-source adaptations, model provenance,
small fitted tensors, comparisons and code excerpts. Full external weight files
are available through the pinned URLs in the manifests. Keep an audit read-only
and use synthetic fixtures for any new inference.
